<?php return array (
  'concurrency' => 
  array (
    'default' => 'process',
  ),
  'app' => 
  array (
    'name' => 'Snipe-IT',
    'env' => 'local',
    'debug' => false,
    'url' => 'http://localhost:8080',
    'frontend_url' => 'http://localhost:3000',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en-US',
    'fallback_locale' => 'en-US',
    'faker_locale' => 'en_US',
    'cipher' => 'AES-256-CBC',
    'key' => 'base64:DQQKw6/gqH7zHnW9YQ+T52q0EJJ3FRnAvZ31hBqEJj0=',
    'previous_keys' => 
    array (
    ),
    'maintenance' => 
    array (
      'driver' => 'file',
      'store' => 'database',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'App\\Providers\\SnipeTranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Intervention\\Image\\ImageServiceProvider',
      23 => 'Collective\\Html\\HtmlServiceProvider',
      24 => 'Spatie\\Backup\\BackupServiceProvider',
      25 => 'PragmaRX\\Google2FALaravel\\ServiceProvider',
      26 => 'Laravel\\Passport\\PassportServiceProvider',
      27 => 'Laravel\\Tinker\\TinkerServiceProvider',
      28 => 'Unicodeveloper\\DumbPassword\\DumbPasswordServiceProvider',
      29 => 'Eduardokum\\LaravelMailAutoEmbed\\ServiceProvider',
      30 => 'Laravel\\Socialite\\SocialiteServiceProvider',
      31 => 'Elibyy\\TCPDF\\ServiceProvider',
      32 => 'App\\Providers\\AppServiceProvider',
      33 => 'App\\Providers\\AuthServiceProvider',
      34 => 'App\\Providers\\EventServiceProvider',
      35 => 'App\\Providers\\RouteServiceProvider',
      36 => 'App\\Providers\\SettingsServiceProvider',
      37 => 'App\\Providers\\ValidationServiceProvider',
      38 => 'App\\Providers\\BladeServiceProvider',
      39 => 'App\\Providers\\LivewireServiceProvider',
      40 => 'App\\Providers\\MacroServiceProvider',
      41 => 'App\\Providers\\SamlServiceProvider',
      42 => 'App\\Providers\\BreadcrumbsServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'PDF' => 'Elibyy\\TCPDF\\Facades\\TCPDF',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
      'Google2FA' => 'PragmaRX\\Google2FALaravel\\Facade',
      'Image' => 'Intervention\\Image\\ImageServiceProvider',
      'Carbon' => 'Carbon\\Carbon',
      'Helper' => 'App\\Helpers\\Helper',
      'StorageHelper' => 'App\\Helpers\\StorageHelper',
      'Icon' => 'App\\Helpers\\IconHelper',
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
    ),
    'max_results' => '500',
    'warn_debug' => true,
    'private_uploads' => '/var/www/html/storage/private_uploads',
    'allow_iframing' => false,
    'enable_hsts' => false,
    'referrer_policy' => 'same-origin',
    'enable_csp' => true,
    'additional_csp_urls' => '',
    'require_saml' => false,
    'saml_key_size' => 2048,
    'lock_passwords' => false,
    'min_php' => '8.2.0',
    'api_throttle_per_minute' => 120,
    'allow_purge' => false,
    'allow_backup_delete' => false,
    'escape_formulas' => true,
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'passport',
        'provider' => 'users',
        'hash' => false,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'email' => 'auth.emails.password',
        'table' => 'password_resets',
        'expire' => 900,
        'throttle' => 
        array (
          'max_attempts' => 5,
          'lockout_duration' => 60,
        ),
      ),
      'invites' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 2880,
        'throttle' => 
        array (
          'max_attempts' => 5,
          'lockout_duration' => 60,
        ),
      ),
    ),
    'password_timeout' => 10800,
    'password_reset' => 
    array (
      'max_attempts_per_min' => 50,
    ),
    'login_autocomplete' => false,
  ),
  'backup' => 
  array (
    'backup' => 
    array (
      'name' => 'backups',
      'source' => 
      array (
        'files' => 
        array (
          'relative_path' => '/var/www/html',
          'include' => 
          array (
            0 => '/var/www/html/public/uploads',
            1 => '/var/www/html/storage/private_uploads',
            2 => '/var/www/html/storage/oauth-private.key',
            3 => '/var/www/html/storage/oauth-public.key',
          ),
          'exclude' => 
          array (
            0 => '/var/www/html/vendor',
            1 => '/var/www/html/config',
            2 => '/var/www/html/node_modules',
          ),
          'follow_links' => false,
          'ignore_unreadable_directories' => false,
        ),
        'databases' => 
        array (
          0 => 'mysql',
        ),
      ),
      'database_dump_compressor' => NULL,
      'destination' => 
      array (
        'filename_prefix' => 'snipe-it-',
        'disks' => 
        array (
          0 => 'backup',
        ),
      ),
      'temporary_directory' => '/var/www/html/storage/app/backup-temp',
      'encryption' => NULL,
    ),
    'notifications' => 
    array (
      'notifications' => 
      array (
        'Spatie\\Backup\\Notifications\\Notifications\\BackupHasFailedNotification' => 
        array (
          0 => NULL,
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\UnhealthyBackupWasFoundNotification' => 
        array (
          0 => NULL,
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupHasFailedNotification' => 
        array (
          0 => NULL,
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\BackupWasSuccessfulNotification' => 
        array (
          0 => NULL,
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\HealthyBackupWasFoundNotification' => 
        array (
          0 => NULL,
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupWasSuccessfulNotification' => 
        array (
          0 => NULL,
        ),
      ),
      'notifiable' => 'Spatie\\Backup\\Notifications\\Notifiable',
      'mail' => 
      array (
        'to' => NULL,
        'from' => 
        array (
          'address' => 'tuannm180220@gmail.com',
          'name' => 'Snipe-IT',
        ),
      ),
      'slack' => 
      array (
        'webhook_url' => '',
        'channel' => NULL,
        'username' => NULL,
        'icon' => NULL,
      ),
      'discord' => 
      array (
        'webhook_url' => '',
        'username' => '',
        'avatar_url' => '',
      ),
    ),
    'monitor_backups' => 
    array (
      0 => 
      array (
        'name' => 'Snipe-IT',
        'disks' => 
        array (
          0 => 'local',
        ),
        'health_checks' => 
        array (
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumAgeInDays' => 1,
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumStorageInMegabytes' => 5000,
        ),
      ),
    ),
    'cleanup' => 
    array (
      'strategy' => 'Spatie\\Backup\\Tasks\\Cleanup\\Strategies\\DefaultStrategy',
      'default_strategy' => 
      array (
        'keep_all_backups_for_days' => 7,
        'keep_daily_backups_for_days' => 16,
        'keep_weekly_backups_for_weeks' => 8,
        'keep_monthly_backups_for_months' => 4,
        'keep_yearly_backups_for_years' => 2,
        'delete_oldest_backups_when_using_more_megabytes_than' => 5000,
      ),
    ),
    'sanitize_by_default' => false,
  ),
  'broadcasting' => 
  array (
    'default' => 'null',
    'connections' => 
    array (
      'reverb' => 
      array (
        'driver' => 'reverb',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'host' => NULL,
          'port' => 443,
          'scheme' => 'https',
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'cluster' => NULL,
          'useTLS' => true,
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/var/www/html/storage/framework/cache',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => NULL,
        'secret' => NULL,
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
      'apc' => 
      array (
        'driver' => 'apc',
      ),
    ),
    'prefix' => 'laravel_cache',
  ),
  'compile' => 
  array (
    'files' => 
    array (
    ),
    'providers' => 
    array (
    ),
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => 'GET',
      1 => 'POST',
      2 => 'PUT',
      3 => 'PATCH',
      4 => 'DELETE',
    ),
    'allowed_origins' => 
    array (
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => '/var/www/html/database/database.sqlite',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => 'db',
        'port' => '3306',
        'database' => 'snipeit',
        'username' => 'root',
        'password' => 'root',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => NULL,
        'strict' => false,
        'engine' => 'InnoDB',
        'unix_socket' => '',
        'dump' => 
        array (
          'dump_binary_path' => '/usr/bin',
          'use_single_transaction' => false,
          'timeout' => 300,
        ),
        'dump_command_timeout' => 300,
        'dump_using_single_transaction' => true,
        'options' => 
        array (
        ),
      ),
      'mariadb' => 
      array (
        'driver' => 'mariadb',
        'url' => NULL,
        'host' => 'db',
        'port' => '3306',
        'database' => 'snipeit',
        'username' => 'root',
        'password' => 'root',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => 'db',
        'port' => '3306',
        'database' => 'snipeit',
        'username' => 'root',
        'password' => 'root',
        'charset' => 'utf8',
        'prefix' => '',
        'schema' => 'public',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'host' => 'db',
        'database' => 'snipeit',
        'username' => 'root',
        'password' => 'root',
        'charset' => 'utf8',
        'prefix' => '',
      ),
      'sqlite_testing' => 
      array (
        'driver' => 'sqlite',
        'database' => ':memory:',
        'prefix' => '',
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'cluster' => false,
      'default' => 
      array (
        'host' => 'localhost',
        'password' => NULL,
        'port' => 6379,
        'database' => 0,
      ),
    ),
    'fetch' => 8,
  ),
  'debugbar' => 
  array (
    'enabled' => NULL,
    'hide_empty_tabs' => true,
    'except' => 
    array (
      0 => 'telescope*',
      1 => 'horizon*',
    ),
    'storage' => 
    array (
      'enabled' => true,
      'driver' => 'file',
      'path' => '/var/www/html/storage/debugbar',
      'connection' => NULL,
    ),
    'editor' => 'phpstorm',
    'remote_sites_path' => NULL,
    'local_sites_path' => NULL,
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'ajax_handler_auto_show' => true,
    'ajax_handler_enable_tab' => true,
    'defer_datasets' => false,
    'error_handler' => false,
    'clockwork' => true,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'laravel' => true,
      'events' => true,
      'default_request' => false,
      'symfony_request' => true,
      'mail' => true,
      'logs' => true,
      'files' => true,
      'config' => false,
      'auth' => true,
      'gate' => true,
      'session' => true,
    ),
    'options' => 
    array (
      'auth' => 
      array (
        'show_name' => false,
      ),
      'db' => 
      array (
        'with_params' => true,
        'timeline' => true,
        'backtrace' => true,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
          ),
        ),
        'hints' => true,
      ),
      'mail' => 
      array (
        'full_log' => false,
      ),
      'views' => 
      array (
        'data' => false,
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_middleware' => 
    array (
    ),
    'route_domain' => NULL,
    'theme' => 'auto',
    'debug_backtrace_limit' => 50,
  ),
  'dompdf' => 
  array (
    'show_warnings' => false,
    'orientation' => 'portrait',
    'convert_entities' => false,
    'defines' => 
    array (
      'font_dir' => '/var/www/html/storage/fonts',
      'font_cache' => '/var/www/html/storage/fonts',
      'temp_dir' => '/tmp',
      'chroot' => '/var/www/html,/var/lib/snipeit/data/uploads,/var/lib/snipeit/data/private_uploads',
      'enable_font_subsetting' => true,
      'pdf_backend' => 'CPDF',
      'default_media_type' => 'screen',
      'default_paper_size' => 'a4',
      'default_font' => 'serif',
      'dpi' => 96,
      'enable_php' => false,
      'enable_javascript' => true,
      'enable_remote' => true,
      'font_height_ratio' => 1.1,
      'enable_html5_parser' => false,
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/storage',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/public/uploads',
        'url' => 'http://localhost:8080/uploads',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
        'report' => false,
      ),
      'local_public' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/public/uploads',
        'url' => 'http://localhost:8080/uploads',
        'visibility' => 'public',
      ),
      's3_public' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
        'root' => NULL,
        'visibility' => 'public',
      ),
      's3_private' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
        'root' => NULL,
        'visibility' => 'private',
      ),
      'rackspace' => 
      array (
        'driver' => 'rackspace',
        'username' => NULL,
        'key' => NULL,
        'container' => NULL,
        'endpoint' => 'https://identity.api.rackspacecloud.com/v2.0/',
        'region' => NULL,
        'url_type' => NULL,
      ),
      'backup' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/storage/app',
      ),
    ),
    'links' => 
    array (
      '/var/www/html/public/storage' => '/var/www/html/storage/app/public',
    ),
    'cloud' => 's3',
    'allowed_upload_extensions_array' => 
    array (
      0 => 'avif',
      1 => 'doc',
      2 => 'doc',
      3 => 'docx',
      4 => 'docx',
      5 => 'gif',
      6 => 'ico',
      7 => 'jpeg',
      8 => 'jpg',
      9 => 'json',
      10 => 'key',
      11 => 'lic',
      12 => 'mov',
      13 => 'mp3',
      14 => 'mp4',
      15 => 'odp',
      16 => 'ods',
      17 => 'odt',
      18 => 'ogg',
      19 => 'pdf',
      20 => 'png',
      21 => 'rar',
      22 => 'rtf',
      23 => 'svg',
      24 => 'txt',
      25 => 'wav',
      26 => 'webm',
      27 => 'webp',
      28 => 'xls',
      29 => 'xlsx',
      30 => 'xml',
      31 => 'zip',
    ),
    'allowed_upload_mimetypes_array' => 
    array (
      0 => 'application/json',
      1 => 'application/msword',
      2 => 'application/pdf',
      3 => 'application/vnd.ms-excel',
      4 => 'application/vnd.oasis.opendocument.presentation',
      5 => 'application/vnd.oasis.opendocument.spreadsheet',
      6 => 'application/vnd.oasis.opendocument.text',
      7 => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      8 => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      9 => 'application/x-rar-compressed',
      10 => 'application/zip',
      11 => 'audio/*',
      12 => 'image/*',
      13 => 'text/plain',
      14 => 'text/rtf',
      15 => 'text/xml',
      16 => 'video/*',
    ),
    'allowed_upload_mimetypes' => 'application/json,application/msword,application/pdf,application/vnd.ms-excel,application/vnd.oasis.opendocument.presentation,application/vnd.oasis.opendocument.spreadsheet,application/vnd.oasis.opendocument.text,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/x-rar-compressed,application/zip,audio/*,image/*,text/plain,text/rtf,text/xml,video/*',
    'allowed_upload_extensions_for_validator' => 'avif,doc,doc,docx,docx,gif,ico,jpeg,jpg,json,key,lic,mov,mp3,mp4,odp,ods,odt,ogg,pdf,png,rar,rtf,svg,txt,wav,webm,webp,xls,xlsx,xml,zip',
    'allowed_upload_extensions' => '.avif, .doc, .doc, .docx, .docx, .gif, .ico, .jpeg, .jpg, .json, .key, .lic, .mov, .mp3, .mp4, .odp, .ods, .odt, .ogg, .pdf, .png, .rar, .rtf, .svg, .txt, .wav, .webm, .webp, .xls, .xlsx, .xml, .zip',
  ),
  'google2fa' => 
  array (
    'enabled' => true,
    'lifetime' => 0,
    'keep_alive' => true,
    'auth' => 'auth',
    'guard' => '',
    'session_var' => 'google2fa',
    'otp_input' => 'one_time_password',
    'window' => 1,
    'forbid_old_passwords' => false,
    'otp_secret_column' => 'google2fa_secret',
    'view' => 'google2fa.index',
    'error_messages' => 
    array (
      'wrong_otp' => 'The \'One Time Password\' typed was wrong.',
      'cannot_be_empty' => 'One Time Password cannot be empty.',
      'unknown' => 'An unknown error has occurred. Please try again.',
    ),
    'throw_exceptions' => true,
    'qrcode_image_backend' => 'svg',
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
    'rehash_on_login' => true,
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'insights' => 
  array (
    'preset' => 'laravel',
    'ide' => NULL,
    'exclude' => 
    array (
    ),
    'add' => 
    array (
      'NunoMaduro\\PhpInsights\\Domain\\Metrics\\Architecture\\Classes' => 
      array (
        0 => 'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenFinalClasses',
      ),
    ),
    'remove' => 
    array (
      0 => 'SlevomatCodingStandard\\Sniffs\\Namespaces\\AlphabeticallySortedUsesSniff',
      1 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\DeclareStrictTypesSniff',
      2 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\DisallowMixedTypeHintSniff',
      3 => 'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenDefineFunctions',
      4 => 'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenNormalClasses',
      5 => 'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenTraits',
      6 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\ParameterTypeHintSniff',
      7 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\PropertyTypeHintSniff',
      8 => 'SlevomatCodingStandard\\Sniffs\\TypeHints\\ReturnTypeHintSniff',
      9 => 'SlevomatCodingStandard\\Sniffs\\Commenting\\UselessFunctionDocCommentSniff',
    ),
    'config' => 
    array (
      'NunoMaduro\\PhpInsights\\Domain\\Insights\\ForbiddenPrivateMethods' => 
      array (
        'title' => 'The usage of private methods is not idiomatic in Laravel.',
      ),
    ),
    'requirements' => 
    array (
    ),
    'threads' => NULL,
  ),
  'livewire' => 
  array (
    'class_namespace' => 'App\\Livewire',
    'view_path' => '/var/www/html/resources/views/livewire',
    'layout' => 'components.layouts.app',
    'lazy_placeholder' => NULL,
    'temporary_file_upload' => 
    array (
      'disk' => 'local',
      'rules' => NULL,
      'directory' => NULL,
      'middleware' => NULL,
      'preview_mimes' => 
      array (
        0 => 'png',
        1 => 'gif',
        2 => 'bmp',
        3 => 'svg',
        4 => 'wav',
        5 => 'mp4',
        6 => 'mov',
        7 => 'avi',
        8 => 'wmv',
        9 => 'mp3',
        10 => 'm4a',
        11 => 'jpg',
        12 => 'jpeg',
        13 => 'mpga',
        14 => 'webp',
        15 => 'wma',
      ),
      'max_upload_time' => 5,
      'cleanup' => true,
    ),
    'render_on_redirect' => false,
    'legacy_model_binding' => true,
    'inject_assets' => true,
    'navigate' => 
    array (
      'show_progress_bar' => true,
      'progress_bar_color' => '#2299dd',
    ),
    'inject_morph_markers' => true,
    'pagination_theme' => 'tailwind',
    'url_prefix' => NULL,
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => 'null',
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/var/www/html/storage/logs/laravel.log',
        'level' => 'warning',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/var/www/html/storage/logs/laravel.log',
        'level' => 'warning',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'warning',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'warning',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'warning',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'warning',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/var/www/html/storage/logs/laravel.log',
      ),
      'scimtrace' => 
      array (
        'driver' => 'single',
        'path' => '/var/www/html/storage/logs/scim.log',
      ),
      'rollbar' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Rollbar\\Laravel\\MonologHandler',
        'access_token' => NULL,
        'level' => 'error',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.gmail.com',
        'port' => '587',
        'username' => 'tuannm180220@gmail.com',
        'password' => 'mayb kdxy ysqo jgwf',
        'timeout' => 30,
        'encryption' => 'tls',
        'verify_peer' => true,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'resend' => 
      array (
        'transport' => 'resend',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
      'roundrobin' => 
      array (
        'transport' => 'roundrobin',
        'mailers' => 
        array (
          0 => 'ses',
          1 => 'postmark',
        ),
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
    ),
    'from' => 
    array (
      'address' => 'tuannm180220@gmail.com',
      'name' => 'Snipe-IT',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/var/www/html/resources/views/vendor/mail',
      ),
    ),
    'reply_to' => 
    array (
      'address' => 'tuannm180220@gmail.com',
      'name' => 'Snipe-IT',
    ),
  ),
  'mail-auto-embed' => 
  array (
    'enabled' => true,
    'method' => 'attachment',
    'curl' => 
    array (
      'connect_timeout' => 5,
      'timeout' => 10,
      'cache' => false,
      'cache_ttl' => 3600,
    ),
  ),
  'passport' => 
  array (
    'guard' => 'web',
    'private_key' => NULL,
    'public_key' => NULL,
    'connection' => NULL,
    'client_uuids' => false,
    'personal_access_client' => 
    array (
      'id' => NULL,
      'secret' => NULL,
    ),
    'expiration_years' => 20,
    'cookie_name' => 'snipeit_passport_token',
  ),
  'pdf' => 
  array (
    'mode' => 'utf-8',
    'format' => 'A4',
    'author' => '',
    'subject' => '',
    'keywords' => '',
    'creator' => 'Snipe-IT',
    'display_mode' => 'fullpage',
    'tempDir' => '/var/www/html/../temp/',
    'pdf_a' => false,
    'pdf_a_auto' => false,
    'icc_profile_path' => '',
    'defaultCssFile' => false,
    'pdfWrapper' => 'misterspelik\\LaravelPdf\\Wrapper\\PdfWrapper',
  ),
  'permissions' => 
  array (
    'Superuser' => 
    array (
      0 => 
      array (
        'permission' => 'superuser',
        'display' => true,
      ),
    ),
    'Admin' => 
    array (
      0 => 
      array (
        'permission' => 'admin',
        'display' => true,
      ),
    ),
    'Import' => 
    array (
      0 => 
      array (
        'permission' => 'import',
        'display' => true,
      ),
    ),
    'Reports' => 
    array (
      0 => 
      array (
        'permission' => 'reports.view',
        'display' => true,
      ),
    ),
    'Assets' => 
    array (
      0 => 
      array (
        'permission' => 'assets.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'assets.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'assets.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'assets.delete',
        'display' => true,
      ),
      4 => 
      array (
        'permission' => 'assets.checkout',
        'display' => false,
      ),
      5 => 
      array (
        'permission' => 'assets.checkin',
        'display' => true,
      ),
      6 => 
      array (
        'permission' => 'assets.checkout',
        'display' => true,
      ),
      7 => 
      array (
        'permission' => 'assets.audit',
        'display' => true,
      ),
      8 => 
      array (
        'permission' => 'assets.view.requestable',
        'display' => true,
      ),
      9 => 
      array (
        'permission' => 'assets.view.encrypted_custom_fields',
        'display' => true,
      ),
    ),
    'Accessories' => 
    array (
      0 => 
      array (
        'permission' => 'accessories.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'accessories.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'accessories.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'accessories.delete',
        'display' => true,
      ),
      4 => 
      array (
        'permission' => 'accessories.checkout',
        'display' => true,
      ),
      5 => 
      array (
        'permission' => 'accessories.checkin',
        'display' => true,
      ),
      6 => 
      array (
        'permission' => 'accessories.files',
        'display' => true,
      ),
    ),
    'Consumables' => 
    array (
      0 => 
      array (
        'permission' => 'consumables.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'consumables.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'consumables.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'consumables.delete',
        'display' => true,
      ),
      4 => 
      array (
        'permission' => 'consumables.checkout',
        'display' => true,
      ),
      5 => 
      array (
        'permission' => 'consumables.files',
        'display' => true,
      ),
    ),
    'Licenses' => 
    array (
      0 => 
      array (
        'permission' => 'licenses.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'licenses.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'licenses.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'licenses.delete',
        'display' => true,
      ),
      4 => 
      array (
        'permission' => 'licenses.checkout',
        'display' => true,
      ),
      5 => 
      array (
        'permission' => 'licenses.checkin',
        'display' => true,
      ),
      6 => 
      array (
        'permission' => 'licenses.keys',
        'display' => true,
      ),
      7 => 
      array (
        'permission' => 'licenses.files',
        'display' => true,
      ),
    ),
    'Components' => 
    array (
      0 => 
      array (
        'permission' => 'components.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'components.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'components.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'components.delete',
        'display' => true,
      ),
      4 => 
      array (
        'permission' => 'components.checkout',
        'display' => true,
      ),
      5 => 
      array (
        'permission' => 'components.checkin',
        'display' => true,
      ),
      6 => 
      array (
        'permission' => 'components.files',
        'display' => true,
      ),
    ),
    'Kits' => 
    array (
      0 => 
      array (
        'permission' => 'kits.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'kits.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'kits.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'kits.delete',
        'display' => true,
      ),
    ),
    'Users' => 
    array (
      0 => 
      array (
        'permission' => 'users.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'users.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'users.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'users.delete',
        'display' => true,
      ),
    ),
    'Models' => 
    array (
      0 => 
      array (
        'permission' => 'models.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'models.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'models.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'models.delete',
        'display' => true,
      ),
    ),
    'Categories' => 
    array (
      0 => 
      array (
        'permission' => 'categories.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'categories.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'categories.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'categories.delete',
        'display' => true,
      ),
    ),
    'Departments' => 
    array (
      0 => 
      array (
        'permission' => 'departments.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'departments.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'departments.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'departments.delete',
        'display' => true,
      ),
    ),
    'Status Labels' => 
    array (
      0 => 
      array (
        'permission' => 'statuslabels.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'statuslabels.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'statuslabels.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'statuslabels.delete',
        'display' => true,
      ),
    ),
    'Custom Fields' => 
    array (
      0 => 
      array (
        'permission' => 'customfields.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'customfields.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'customfields.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'customfields.delete',
        'display' => true,
      ),
    ),
    'Suppliers' => 
    array (
      0 => 
      array (
        'permission' => 'suppliers.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'suppliers.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'suppliers.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'suppliers.delete',
        'display' => true,
      ),
    ),
    'Manufacturers' => 
    array (
      0 => 
      array (
        'permission' => 'manufacturers.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'manufacturers.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'manufacturers.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'manufacturers.delete',
        'display' => true,
      ),
    ),
    'Depreciations' => 
    array (
      0 => 
      array (
        'permission' => 'depreciations.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'depreciations.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'depreciations.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'depreciations.delete',
        'display' => true,
      ),
    ),
    'Locations' => 
    array (
      0 => 
      array (
        'permission' => 'locations.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'locations.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'locations.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'locations.delete',
        'display' => true,
      ),
    ),
    'Companies' => 
    array (
      0 => 
      array (
        'permission' => 'companies.view',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'companies.create',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'companies.edit',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'companies.delete',
        'display' => true,
      ),
    ),
    'User (Self) Accounts' => 
    array (
      0 => 
      array (
        'permission' => 'self.two_factor',
        'display' => true,
      ),
      1 => 
      array (
        'permission' => 'self.api',
        'display' => true,
      ),
      2 => 
      array (
        'permission' => 'self.edit_location',
        'display' => true,
      ),
      3 => 
      array (
        'permission' => 'self.checkout_assets',
        'display' => true,
      ),
      4 => 
      array (
        'permission' => 'self.view_purchase_cost',
        'display' => true,
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => NULL,
        'secret' => NULL,
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'scim' => 
  array (
    'publish_routes' => false,
    'omit_main_schema_in_return' => true,
    'trace' => false,
  ),
  'services' => 
  array (
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'resend' => 
    array (
      'key' => NULL,
    ),
    'slack' => 
    array (
      'notifications' => 
      array (
        'bot_user_oauth_token' => NULL,
        'channel' => NULL,
      ),
    ),
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'mandrill' => 
    array (
      'secret' => NULL,
    ),
    'stripe' => 
    array (
      'model' => 'App\\User',
      'key' => NULL,
      'secret' => NULL,
    ),
    'google' => 
    array (
      'maps_api_key' => NULL,
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 12000,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/var/www/html/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'snipeitv6_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
    'same_site' => 'lax',
    'partitioned' => false,
    'bs_table_storage' => 'localStorage',
    'bs_table_addrbar' => true,
  ),
  'telescope' => 
  array (
    'enabled' => false,
    'domain' => NULL,
    'path' => 'telescope',
    'driver' => 'database',
    'storage' => 
    array (
      'database' => 
      array (
        'connection' => 'mysql',
        'chunk' => 1000,
      ),
    ),
    'queue' => 
    array (
      'connection' => NULL,
      'queue' => NULL,
      'delay' => 10,
    ),
    'middleware' => 
    array (
      0 => 'web',
      1 => 'Laravel\\Telescope\\Http\\Middleware\\Authorize',
    ),
    'only_paths' => 
    array (
    ),
    'ignore_paths' => 
    array (
      0 => 'livewire*',
    ),
    'ignore_commands' => 
    array (
    ),
    'watchers' => 
    array (
      'Laravel\\Telescope\\Watchers\\BatchWatcher' => true,
      'Laravel\\Telescope\\Watchers\\CacheWatcher' => 
      array (
        'enabled' => true,
        'hidden' => 
        array (
        ),
        'ignore' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\ClientRequestWatcher' => true,
      'Laravel\\Telescope\\Watchers\\CommandWatcher' => 
      array (
        'enabled' => true,
        'ignore' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\DumpWatcher' => 
      array (
        'enabled' => true,
        'always' => false,
      ),
      'Laravel\\Telescope\\Watchers\\EventWatcher' => 
      array (
        'enabled' => true,
        'ignore' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\ExceptionWatcher' => true,
      'Laravel\\Telescope\\Watchers\\GateWatcher' => 
      array (
        'enabled' => true,
        'ignore_abilities' => 
        array (
        ),
        'ignore_packages' => true,
        'ignore_paths' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\JobWatcher' => true,
      'Laravel\\Telescope\\Watchers\\LogWatcher' => 
      array (
        'enabled' => true,
        'level' => 'error',
      ),
      'Laravel\\Telescope\\Watchers\\MailWatcher' => true,
      'Laravel\\Telescope\\Watchers\\ModelWatcher' => 
      array (
        'enabled' => true,
        'events' => 
        array (
          0 => 'eloquent.*',
        ),
        'hydrations' => true,
      ),
      'Laravel\\Telescope\\Watchers\\NotificationWatcher' => true,
      'Laravel\\Telescope\\Watchers\\QueryWatcher' => 
      array (
        'enabled' => true,
        'ignore_packages' => true,
        'ignore_paths' => 
        array (
        ),
        'slow' => 100,
      ),
      'Laravel\\Telescope\\Watchers\\RedisWatcher' => true,
      'Laravel\\Telescope\\Watchers\\RequestWatcher' => 
      array (
        'enabled' => true,
        'size_limit' => 64,
        'ignore_http_methods' => 
        array (
        ),
        'ignore_status_codes' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\ScheduleWatcher' => true,
      'Laravel\\Telescope\\Watchers\\ViewWatcher' => true,
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => '*',
  ),
  'version' => 
  array (
    'app_version' => 'v8.3.4',
    'full_app_version' => 'v8.3.4 - build 20218-g3ab2e2011',
    'build_version' => '20218',
    'prerelease_version' => '',
    'hash_version' => 'g3ab2e2011',
    'full_hash' => 'v8.3.4-149-g3ab2e2011',
    'branch' => 'master',
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/var/www/html/resources/views',
    ),
    'compiled' => '/var/www/html/storage/framework/views',
  ),
  'tcpdf' => 
  array (
    'page_format' => 'A4',
    'page_orientation' => 'P',
    'page_units' => 'mm',
    'unicode' => true,
    'encoding' => 'UTF-8',
    'font_directory' => '',
    'image_directory' => '',
    'tcpdf_throw_exception' => false,
    'use_fpdi' => false,
    'use_original_header' => false,
    'use_original_footer' => false,
    'pdfa' => false,
  ),
  'google-chat' => 
  array (
    'space' => NULL,
    'spaces' => 
    array (
    ),
  ),
  'teams' => 
  array (
    'webhook_url' => NULL,
    'verify_ssl' => true,
  ),
  'flare' => 
  array (
    'key' => NULL,
    'flare_middleware' => 
    array (
      0 => 'Spatie\\FlareClient\\FlareMiddleware\\RemoveRequestIp',
      1 => 'Spatie\\FlareClient\\FlareMiddleware\\AddGitInformation',
      2 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddNotifierName',
      3 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddEnvironmentInformation',
      4 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionInformation',
      5 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddDumps',
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddLogs' => 
      array (
        'maximum_number_of_collected_logs' => 200,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddQueries' => 
      array (
        'maximum_number_of_collected_queries' => 200,
        'report_query_bindings' => true,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddJobs' => 
      array (
        'max_chained_job_reporting_depth' => 5,
      ),
      6 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddContext',
      7 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionHandledStatus',
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestBodyFields' => 
      array (
        'censor_fields' => 
        array (
          0 => 'password',
          1 => 'password_confirmation',
        ),
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestHeaders' => 
      array (
        'headers' => 
        array (
          0 => 'API-KEY',
          1 => 'Authorization',
          2 => 'Cookie',
          3 => 'Set-Cookie',
          4 => 'X-CSRF-TOKEN',
          5 => 'X-XSRF-TOKEN',
        ),
      ),
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'auto',
    'enable_share_button' => true,
    'register_commands' => false,
    'solution_providers' => 
    array (
      0 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\BadMethodCallSolutionProvider',
      1 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\MergeConflictSolutionProvider',
      2 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\UndefinedPropertySolutionProvider',
      3 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\IncorrectValetDbCredentialsSolutionProvider',
      4 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingAppKeySolutionProvider',
      5 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\DefaultDbNameSolutionProvider',
      6 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\TableNotFoundSolutionProvider',
      7 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingImportSolutionProvider',
      8 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\InvalidRouteActionSolutionProvider',
      9 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\ViewNotFoundSolutionProvider',
      10 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\RunningLaravelDuskInProductionProvider',
      11 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingColumnSolutionProvider',
      12 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownValidationSolutionProvider',
      13 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingMixManifestSolutionProvider',
      14 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingViteManifestSolutionProvider',
      15 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingLivewireComponentSolutionProvider',
      16 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UndefinedViewVariableSolutionProvider',
      17 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\GenericLaravelExceptionSolutionProvider',
      18 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\OpenAiSolutionProvider',
      19 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\SailNetworkSolutionProvider',
      20 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownMysql8CollationSolutionProvider',
      21 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownMariadbCollationSolutionProvider',
    ),
    'ignored_solution_providers' => 
    array (
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '/var/www/html',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
    'settings_file_path' => '',
    'recorders' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\Recorders\\DumpRecorder\\DumpRecorder',
      1 => 'Spatie\\LaravelIgnition\\Recorders\\JobRecorder\\JobRecorder',
      2 => 'Spatie\\LaravelIgnition\\Recorders\\LogRecorder\\LogRecorder',
      3 => 'Spatie\\LaravelIgnition\\Recorders\\QueryRecorder\\QueryRecorder',
    ),
    'open_ai_key' => NULL,
    'with_stack_frame_arguments' => true,
    'argument_reducers' => 
    array (
      0 => 'Spatie\\Backtrace\\Arguments\\Reducers\\BaseTypeArgumentReducer',
      1 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ArrayArgumentReducer',
      2 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StdClassArgumentReducer',
      3 => 'Spatie\\Backtrace\\Arguments\\Reducers\\EnumArgumentReducer',
      4 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ClosureArgumentReducer',
      5 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeArgumentReducer',
      6 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeZoneArgumentReducer',
      7 => 'Spatie\\Backtrace\\Arguments\\Reducers\\SymphonyRequestArgumentReducer',
      8 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\ModelArgumentReducer',
      9 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\CollectionArgumentReducer',
      10 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StringableArgumentReducer',
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
