<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/_debugbar/open' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.openhandler',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_debugbar/assets/stylesheets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.assets.css',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_debugbar/assets/javascript' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.assets.js',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_debugbar/queries/explain' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.queries.explain',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/token' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.token',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/authorize' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.authorizations.authorize',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.authorizations.approve',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'passport.authorizations.deny',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/token/refresh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.token.refresh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/tokens' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.tokens.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/clients' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/scopes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.scopes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/personal-access-tokens' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.personal.tokens.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.personal.tokens.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.min.js' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hutaOzGZLN5cFHNQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.min.js.map' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lqziNWhtg12L4kSf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/upload-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.upload-file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::luhhPS65gYoOS6a3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/account/requests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.requested',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/account/eulas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.self.eulas',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/account/requestable/hardware' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.requestable',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/account/personal-access-tokens' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.personal-access-token.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.personal-access-token.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/accessories/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.accessories.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/accessories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.accessories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.accessories.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.categories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.categories.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/companies/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.companies.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/companies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.companies.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.companies.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/departments/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.departments.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/departments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.departments.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.departments.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/components/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.components.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/components' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.components.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.components.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/consumables/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.consumables.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/consumables' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.consumables.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.consumables.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/depreciations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.depreciations.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.depreciations.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/reports/depreciation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.depreciation-report.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/fields' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customfields.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customfields.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/fieldsets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.fieldsets.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.fieldsets.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/groups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.groups.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.groups.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/hardware/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assets.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/hardware/checkinbytag' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.asset.checkinbytag',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/hardware/audit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.asset.audit.legacy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/hardware' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/maintenances' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.maintenances.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.maintenances.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/imports' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.imports.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.imports.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/licenses/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.licenses.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/licenses' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.licenses.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.licenses.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/locations/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/locations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/manufacturers/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.manufacturers.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/manufacturers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.manufacturers.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.manufacturers.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/models/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.models.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/models/assets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.models.assets',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/models' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.models.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.models.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/ldaptest' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.ldaptest',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/purge_barcodes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.purgebarcodes',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/login-attempts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.login_attempts',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/ldaptestlogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.ldaptestlogin',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/slacktest' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.slacktest',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/mailtest' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.mailtest',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/backups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.backups.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/backups/download/latest' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.backups.latest',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/statuslabels/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/statuslabels/assets/name' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.assets.byname',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/statuslabels/assets/type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.assets.bytype',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/statuslabels' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/suppliers/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.suppliers.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/suppliers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.suppliers.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.suppliers.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/users/selectlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.selectlist',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/users/ldapsync' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.ldapsync',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/users/two_factor_reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.two_factor_reset',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/users/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.me',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/kits' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/reports/activity' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.activity.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/version' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HxdcYQ97CTNRgaGv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/bulkaudit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assets.bulkaudit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/quickscancheckin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware/quickscancheckin',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/requested' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assets.requested',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/audit/due' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assets.audit.due',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/checkins/due' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assets.checkins.due',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'asset.import-history',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'asset.process-import-history',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/bulkedit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware/bulkedit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/bulkdelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware/bulkdelete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/bulkrestore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware/bulkrestore',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/bulksave' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware/bulksave',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/bulkcheckout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.bulkcheckout.show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.bulkcheckout.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hardware/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/maintenances' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'maintenances.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'maintenances.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/maintenances/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'maintenances.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/models/bulkedit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'models.bulkedit.index',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/models/bulksave' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'models.bulkedit.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/models/bulkdelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'models.bulkdelete.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/models' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'models.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'models.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/models/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'models.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/accessories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/accessories/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/licenses/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/licenses' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/licenses/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/locations/bulkdelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.bulkdelete.show',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/locations/bulkedit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.bulkdelete.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/locations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'locations.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/locations/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/consumables' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/consumables/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/fields/fieldsets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fieldsets.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'fieldsets.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/fields/fieldsets/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fieldsets.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/fields' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fields.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'fields.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/fields/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fields.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/components' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'components.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'components.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/components/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'components.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users/ldap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ldap/user',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::djPLSWcWRo3QhYzF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users/bulkedit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users/bulkedit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users/merge' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.merge.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users/bulksave' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users/bulksave',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users/bulkeditsave' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users/bulkeditsave',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'users.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kits' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'kits.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kits/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/companies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'companies.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'companies.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/companies/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'companies.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'categories.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/categories/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/categories/bulk/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.bulk.delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/test-email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lx1vWfVl9IKehEk8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manufacturers/seed' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manufacturers.seed',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manufacturers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manufacturers.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'manufacturers.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manufacturers/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manufacturers.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manufacturers/bulk/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manufacturers.bulk.delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/suppliers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suppliers.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'suppliers.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/suppliers/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suppliers.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/suppliers/bulk/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suppliers.bulk.delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/depreciations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'depreciations.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'depreciations.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/depreciations/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'depreciations.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statuslabels' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'statuslabels.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'statuslabels.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statuslabels/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'statuslabels.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/departments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'departments.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'departments.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/departments/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'departments.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.general.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.general.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/branding' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.branding.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.branding.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/security' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.security.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.security.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/localization' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.localization.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.localization.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/notifications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.alerts.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.alerts.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/slack' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.slack.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.slack.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/asset_tags' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.asset_tags.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.asset_tags.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/labels' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.labels.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.labels.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ldap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.ldap.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.ldap.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/phpinfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.phpinfo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/oauth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.oauth.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/google' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.google.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.google.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/purge' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.purge.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.purge.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/login-attempts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.logins.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/saml' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.saml.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.saml.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/backups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.backups.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'settings.backups.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/backups/upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.backups.upload',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/groups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'groups.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'groups.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/groups/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'groups.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'imports.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.menuprefs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.password.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/api' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.api',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/view-assets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'view-assets',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/requested' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.requested',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/requestable-assets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'requestable-assets',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/accept' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.accept',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/print' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.print',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.email_assets',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/notes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'notes.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/audit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports.audit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/depreciation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/depreciation',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/export/depreciation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/export/depreciation',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/maintenances' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ui.reports.maintenances',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/export/maintenances' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/export/maintenances',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/licenses' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/licenses',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/export/licenses' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/export/licenses',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/accessories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/accessories',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/export/accessories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/export/accessories',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/custom' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/custom',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'reports.post-custom',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/templates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'report-templates.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/activity' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports.activity',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'reports.activity.post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/signin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JUpLdOF4RL8RAsaE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/setup/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'setup.user',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'setup.user.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/setup/migrate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'setup.migrate',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/setup/done' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'setup.done',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/setup/mailtest' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'setup.mailtest',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/setup' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'setup',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jPGSTHkTpOwCxpIA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/two-factor-enroll' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor-enroll',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/two-factor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PN2nEoTNcNMAZZPu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/google' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'google.redirect',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/google/callback' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'google.callback',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout.get',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'logout.post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/health' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'health',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/scim/v2/ServiceProviderConfig' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scim.serviceproviderconfig',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/scim/v2/Schemas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OFM2tq9nljKUwhJT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/scim/v2/ResourceTypes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S1a7HI3pEPfYRPXq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/scim/v2/.search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pag4vxGkdscBEYTZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/scim/v1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5h82kf4qL8SvrHas',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/scim/v2/Me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scim.me.get',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'scim.me.put',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BDTliEbkNDMxIk8e',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/saml/metadata' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saml.metadata',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/saml/acs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saml.acs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/saml/sls' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saml.sls',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login/saml' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'saml.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/_debugbar/c(?|lockwork/([^/]++)(*:39)|ache/([^/]++)(?:/([^/]++))?(*:73))|/oauth/(?|tokens/([^/]++)(*:106)|clients/([^/]++)(?|(*:133))|personal\\-access\\-tokens/([^/]++)(*:175))|/l(?|i(?|vewire/preview\\-file/([^/]++)(*:222)|censes/([^/]++)(?|/(?|c(?|lone(*:260)|heck(?|out(?:/([^/]++))?(?|(*:295)|(*:303))|in(?:/([^/]++))?(?|(*:331)|(*:339))))|freecheckout(*:362)|bulkcheck(?|in(*:384)|out(*:395))|edit(*:408))|(*:417)))|ocations/([^/]++)(?|/(?|restore(*:458)|clone(*:471)|printa(?|ssigned(*:495)|llassigned(*:513))|edit(*:526))|(*:535))|abels/(.*)(*:554))|/a(?|pi/v1/(?|acc(?|ount/(?|request/([^/]++)(?|(*:610)|/cancel(*:625))|personal\\-access\\-tokens/([^/]++)(*:667))|essories/([^/]++)(?|/check(?|edout(*:710)|out(*:721)|in(*:731))|(*:740)))|c(?|ategories/([^/]++)(?|/selectlist(*:786)|(*:794))|o(?|mp(?|anies/([^/]++)(?|(*:829))|onents/([^/]++)(?|/(?|assets(*:866)|check(?|in(*:884)|out(*:895)))|(*:905)))|nsumables/([^/]++)(?|/(?|users(*:945)|checkout(*:961))|(*:970))))|dep(?|artments/([^/]++)(?|(*:1007))|reciations/([^/]++)(?|(*:1039)))|fields(?|/(?|fieldsets/([^/]++)/order(*:1087)|([^/]++)(?|/(?|associate(*:1120)|disassociate(*:1141))|(*:1151)))|ets/([^/]++)(?|/fields(?|(*:1187)|/([^/]++)(*:1205))|(*:1215)))|groups/([^/]++)(?|(*:1244))|hardware/(?|([^/]++)/licenses(*:1283)|by(?|tag/(?|([^/]++)(*:1312)|(.*)(*:1325)|([^/]++)/check(?|out(*:1354)|in(*:1365)))|serial/(.*)(*:1387))|(audit|audits|checkins)/(due|overdue|due-or-overdue)(*:1449)|([^/]++)(?|/(?|a(?|udit(*:1481)|ssigned/(?|a(?|ssets(*:1510)|ccessories(*:1529))|components(*:1549)))|check(?|in(*:1570)|out(*:1582))|restore(*:1599))|(*:1609)|(*:1618))|labels(*:1634))|m(?|a(?|intenances/([^/]++)(?|(*:1674))|nufacturers/([^/]++)(?|/restore(*:1715)|(*:1724)))|odels/([^/]++)(?|/restore(*:1760)|(*:1769)))|imports/(?|process/([^/]++)(*:1807)|([^/]++)(?|(*:1827)))|l(?|abels(?|/(.*)(*:1855)|(*:1864))|icenses/([^/]++)(?|(*:1893)|/seats(?|(*:1911)|/([^/]++)(?|(*:1932))))|ocations/([^/]++)(?|/(?|users(*:1973)|ass(?|ets(*:1991)|igned/a(?|ssets(*:2015)|ccessories(*:2034))))|(*:2046)))|notes/([^/]++)/(?|store(*:2080)|index(*:2094))|s(?|ettings/(?|backups/download/([^/]++)(*:2144)|([^/]++)(?|(*:2164)))|tatuslabels/([^/]++)(?|/(?|assetlist(*:2211)|deployable(*:2230))|(*:2240))|uppliers/([^/]++)(?|(*:2270)))|users/(?|([^/]++)/eulas(*:2304)|list(?:/([^/]++))?(*:2331)|([^/]++)(?|/(?|a(?|ssets(*:2364)|ccessories(*:2383))|email(*:2398)|licenses(*:2415)|restore(*:2431))|(*:2441)))|kits/([^/]++)(?|(*:2468)|/(?|licenses(?|(*:2492)|/([^/]++)(?|(*:2513)))|models(?|(*:2533)|/([^/]++)(?|(*:2554)))|accessories(?|(*:2579)|/([^/]++)(?|(*:2600)))|consumables(?|(*:2625)|/([^/]++)(?|(*:2646)))))|(accessories|audits|assets|components|consumables|hardware|licenses|locations|maintenances|models|users)/([^/]++)/files(*:2778)|(accessories|audits|assets|components|consumables|hardware|licenses|locations|maintenances|models|users)/([^/]++)/files/([^/]++)(*:2915)|(accessories|audits|assets|components|consumables|hardware|licenses|locations|maintenances|models|users)/([^/]++)/files(*:3043)|(accessories|assets|components|consumables|hardware|licenses|locations|maintenances|models|users)/([^/]++)/files/([^/]++)/delete(*:3180))|cc(?|essories/([^/]++)(?|/(?|c(?|heck(?|out(?|(*:3236)|(*:3245))|in(?:/([^/]++))?(?|(*:3274)))|lone(?|(*:3292)|(*:3301)))|edit(*:3316))|(*:3326))|ount/(?|request(?|\\-asset/([^/]++)(?|(*:3373)|/cancel(*:3389))|/([^/]++)/([^/]++)(?:/([^/]++)(?:/([^/]++))?)?(*:3445))|display\\-sig/([^/]++)(*:3476)|stored\\-eula\\-file/([^/]++)(*:3512)|accept/([^/]++)(?|(*:3539))))|dmin/(?|backups/(?|d(?|ownload/([^/]++)(*:3590)|elete/([^/]++)(*:3613))|restore(?|/([^/]++)(*:3642)|(?:/([^/]++))?(*:3665)))|groups/([^/]++)(?|(*:3694)|/edit(*:3708)|(*:3717))))|/h(?|ardware/(?|([^/]++)/audit(?|(*:3762))|by(?|tag(?:/(.*))?(*:3790)|serial(?:/(.*))?(*:3815))|([^/]++)(?|/(?|c(?|lone(*:3848)|heck(?|out(?|(*:3870)|(*:3879))|in(?:/([^/]++))?(?|(*:3908)|(*:3917))))|label(*:3934)|view(*:3947)|qr_code(*:3963)|barcode(*:3979)|restore(*:3995)|edit(*:4008))|(*:4018)))|t(?:/(.*))?(*:4040))|/m(?|a(?|intenances/([^/]++)(?|(*:4081)|/edit(*:4095)|(*:4104))|nufacturers/([^/]++)(?|/(?|restore(*:4148)|edit(*:4161))|(*:4171)))|od(?|els/([^/]++)(?|/(?|c(?|lone(?|(*:4217))|ustom_fields(*:4239))|view(*:4253)|restore(*:4269)|edit(*:4282))|(*:4292))|als/([^/]++)(?:/([^/]++))?(*:4328)))|/c(?|o(?|nsumables/([^/]++)(?|/(?|c(?|heckout(?|(*:4387))|lone(*:4401))|edit(*:4415))|(*:4425))|mp(?|onents/([^/]++)(?|/(?|check(?|out(?|(*:4476))|in(?:/([^/]++))?(?|(*:4505)))|edit(*:4520))|(*:4530))|anies/([^/]++)(?|(*:4557)|/edit(*:4571)|(*:4580))))|ategories/([^/]++)(?|(*:4613)|/edit(*:4627)|(*:4636)))|/fields/(?|required/([^/]++)/([^/]++)(*:4684)|optional/([^/]++)/([^/]++)(*:4719)|([^/]++)/fieldset/([^/]++)/disassociate(*:4767)|fieldsets/([^/]++)(?|/(?|associate(*:4810)|edit(*:4823))|(*:4833))|([^/]++)(?|/edit(*:4859)|(*:4868)))|/users/([^/]++)(?|/(?|clone(?|(*:4909))|restore(*:4926)|unsuspend(*:4944)|p(?|assword(*:4964)|rint(*:4977))|e(?|mail(*:4995)|dit(*:5007)))|(*:5018))|/kits/([^/]++)(?|/(?|licenses(?|(*:5060)|/([^/]++)(?|(*:5081)|/edit(*:5095)|(*:5104)))|models/([^/]++)(?|(*:5133)|/edit(*:5147)|(*:5156))|c(?|onsumables/([^/]++)(?|(*:5192)|/edit(*:5206)|(*:5215))|heckout(?|(*:5235)))|accessories/([^/]++)(?|(*:5269)|/edit(*:5283)|(*:5292))|edit(*:5306))|(*:5316))|/s(?|uppliers/([^/]++)(?|(*:5351)|/edit(*:5365)|(*:5374))|t(?|atuslabels/([^/]++)(?|(*:5410)|/edit(*:5424)|(*:5433))|ored\\-eula\\-file/([^/]++)(*:5468)))|/d(?|ep(?|reciations/([^/]++)(?|(*:5511)|/edit(*:5525)|(*:5534))|artments/([^/]++)(?|(*:5564)|/edit(*:5578)|(*:5587)))|isplay\\-sig/([^/]++)(*:5618))|/reports/(?|templates/([^/]++)(?|(*:5661)|/edit(*:5675)|(*:5684))|unaccepted_assets(?|(?:/([^/]++))?(*:5728)|/(?|sent_reminder(*:5754)|([^/]++)/delete(*:5778))|(?:/([^/]++))?(*:5802)))|/password/reset/([^/]++)(*:5837)|/(assets|audits|maintenances|hardware|models|users|locations|accessories|consumables|licenses|components)/([^/]++)/files/([^/]++)(*:5975)|/(assets|audits|maintenances|hardware|models|users|locations|accessories|consumables|licenses|components)/([^/]++)/files(*:6104)|/(assets|maintenances|hardware|models|users|locations|accessories|consumables|licenses|components)/([^/]++)/files/([^/]++)/delete(*:6242)|/scim/v(?|2/(?|Schemas/([^/]++)(*:6282)|ResourceTypes/([^/]++)(*:6313)|((?:(?!Me).)*)/([^/]++)(*:6345)|((?:(?!Me).)*)(?|(*:6371))|((?:(?!Me).)*)/([^/]++)(?|(*:6407))|(.*)(*:6421))|1/(.*)(*:6437))|/api/v1/(.*)(*:6459))/?$}sDu',
    ),
    3 => 
    array (
      39 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.clockwork',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      73 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.cache.delete',
            'tags' => NULL,
          ),
          1 => 
          array (
            0 => 'key',
            1 => 'tags',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      106 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.tokens.destroy',
          ),
          1 => 
          array (
            0 => 'token_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      133 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.update',
          ),
          1 => 
          array (
            0 => 'client_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.destroy',
          ),
          1 => 
          array (
            0 => 'client_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      175 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.personal.tokens.destroy',
          ),
          1 => 
          array (
            0 => 'token_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      222 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.preview-file',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      260 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'clone/license',
          ),
          1 => 
          array (
            0 => 'licenseId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      295 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.checkout',
            'seatId' => NULL,
          ),
          1 => 
          array (
            0 => 'license',
            1 => 'seatId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      303 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9ydZpFMQeZ9viyLe',
            'seatId' => NULL,
          ),
          1 => 
          array (
            0 => 'licenseId',
            1 => 'seatId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.checkin',
            'backto' => NULL,
          ),
          1 => 
          array (
            0 => 'licenseSeat',
            1 => 'backto',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      339 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.checkin.save',
            'backto' => NULL,
          ),
          1 => 
          array (
            0 => 'licenseId',
            1 => 'backto',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      362 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.freecheckout',
          ),
          1 => 
          array (
            0 => 'licenseId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      384 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.bulkcheckin',
          ),
          1 => 
          array (
            0 => 'licenseId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      395 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.bulkcheckout',
          ),
          1 => 
          array (
            0 => 'licenseId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      408 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.edit',
          ),
          1 => 
          array (
            0 => 'license',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      417 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.show',
          ),
          1 => 
          array (
            0 => 'license',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.update',
          ),
          1 => 
          array (
            0 => 'license',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'licenses.destroy',
          ),
          1 => 
          array (
            0 => 'license',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      458 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.restore',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      471 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'clone/location',
          ),
          1 => 
          array (
            0 => 'locationId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      495 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.print_assigned',
          ),
          1 => 
          array (
            0 => 'locationId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      513 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.print_all_assigned',
          ),
          1 => 
          array (
            0 => 'locationId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      526 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.edit',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      535 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.show',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'locations.update',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'locations.destroy',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      554 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'labels.show',
          ),
          1 => 
          array (
            0 => 'labelName',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      610 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.requests.store',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      625 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.requests.destroy',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      667 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.personal-access-token.delete',
          ),
          1 => 
          array (
            0 => 'tokenId',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      710 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.accessories.checkedout',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      721 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.accessories.checkout',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      731 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.accessories.checkin',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      740 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.accessories.show',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.accessories.update',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.accessories.destroy',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      786 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.categories.selectlist',
          ),
          1 => 
          array (
            0 => 'item_type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      794 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.categories.show',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.categories.update',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.categories.destroy',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      829 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.companies.show',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.companies.update',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.companies.destroy',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      866 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.components.assets',
          ),
          1 => 
          array (
            0 => 'component',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      884 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.components.checkin',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      895 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.components.checkout',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      905 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.components.show',
          ),
          1 => 
          array (
            0 => 'component',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.components.update',
          ),
          1 => 
          array (
            0 => 'component',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.components.destroy',
          ),
          1 => 
          array (
            0 => 'component',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      945 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.consumables.show.users',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      961 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.consumables.checkout',
          ),
          1 => 
          array (
            0 => 'consumable',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      970 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.consumables.show',
          ),
          1 => 
          array (
            0 => 'consumable',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.consumables.update',
          ),
          1 => 
          array (
            0 => 'consumable',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.consumables.destroy',
          ),
          1 => 
          array (
            0 => 'consumable',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1007 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.departments.show',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.departments.update',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.departments.destroy',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1039 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.depreciations.show',
          ),
          1 => 
          array (
            0 => 'depreciation_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.depreciations.update',
          ),
          1 => 
          array (
            0 => 'depreciation_id',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.depreciations.destroy',
          ),
          1 => 
          array (
            0 => 'depreciation_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1087 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customfields.order',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1120 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customfields.associate',
          ),
          1 => 
          array (
            0 => 'field',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1141 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customfields.disassociate',
          ),
          1 => 
          array (
            0 => 'field',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1151 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customfields.show',
          ),
          1 => 
          array (
            0 => 'field',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customfields.update',
          ),
          1 => 
          array (
            0 => 'field',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.customfields.destroy',
          ),
          1 => 
          array (
            0 => 'field',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1187 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.fieldsets.fields',
          ),
          1 => 
          array (
            0 => 'fieldset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1205 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.fieldsets.fields-with-default-value',
          ),
          1 => 
          array (
            0 => 'fieldset',
            1 => 'model',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1215 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.fieldsets.show',
          ),
          1 => 
          array (
            0 => 'fieldset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.fieldsets.update',
          ),
          1 => 
          array (
            0 => 'fieldset',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.fieldsets.destroy',
          ),
          1 => 
          array (
            0 => 'fieldset',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1244 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.groups.show',
          ),
          1 => 
          array (
            0 => 'group',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.groups.update',
          ),
          1 => 
          array (
            0 => 'group',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.groups.destroy',
          ),
          1 => 
          array (
            0 => 'group',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1283 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.licenselist',
          ),
          1 => 
          array (
            0 => 'asset_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1312 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assets.show.bytag',
          ),
          1 => 
          array (
            0 => 'tag',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1325 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.show.bytag',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1354 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.checkout.bytag',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1365 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.asset.checkinbytagPath',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.show.byserial',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1449 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.list-upcoming',
          ),
          1 => 
          array (
            0 => 'action',
            1 => 'upcoming_status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1481 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.asset.audit',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1510 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.assigned_assets',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1529 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.assigned_accessories',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1549 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.assigned_components',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1570 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.asset.checkin',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1582 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.asset.checkout',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1599 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.restore',
          ),
          1 => 
          array (
            0 => 'asset_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1609 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.update',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.put-update',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1618 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.show',
          ),
          1 => 
          array (
            0 => 'hardware',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.destroy',
          ),
          1 => 
          array (
            0 => 'hardware',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1634 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.assets.labels',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1674 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.maintenances.show',
          ),
          1 => 
          array (
            0 => 'maintenance',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.maintenances.update',
          ),
          1 => 
          array (
            0 => 'maintenance',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.maintenances.destroy',
          ),
          1 => 
          array (
            0 => 'maintenance',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1715 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.manufacturers.restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1724 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.manufacturers.show',
          ),
          1 => 
          array (
            0 => 'manufacturer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.manufacturers.update',
          ),
          1 => 
          array (
            0 => 'manufacturer',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.manufacturers.destroy',
          ),
          1 => 
          array (
            0 => 'manufacturer',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1760 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.models.restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1769 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.models.show',
          ),
          1 => 
          array (
            0 => 'model',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.models.update',
          ),
          1 => 
          array (
            0 => 'model',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.models.destroy',
          ),
          1 => 
          array (
            0 => 'model',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1807 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.imports.importFile',
          ),
          1 => 
          array (
            0 => 'import',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1827 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.imports.show',
          ),
          1 => 
          array (
            0 => 'import',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.imports.update',
          ),
          1 => 
          array (
            0 => 'import',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.imports.destroy',
          ),
          1 => 
          array (
            0 => 'import',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1855 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.labels.show',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1864 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.labels.index',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1893 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.licenses.show',
          ),
          1 => 
          array (
            0 => 'license_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.licenses.update',
          ),
          1 => 
          array (
            0 => 'license_id',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.licenses.destroy',
          ),
          1 => 
          array (
            0 => 'license_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1911 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.licenses.seats.index',
          ),
          1 => 
          array (
            0 => 'license',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1932 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.licenses.seats.show',
          ),
          1 => 
          array (
            0 => 'license',
            1 => 'seat',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.licenses.seats.update',
          ),
          1 => 
          array (
            0 => 'license',
            1 => 'seat',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.viewusers',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1991 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.viewassets',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2015 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.assigned_assets',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2034 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.assigned_accessories',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2046 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.show',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.update',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.locations.destroy',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2080 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.notes.store',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2094 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.notes.index',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2144 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.backups.download',
          ),
          1 => 
          array (
            0 => 'file',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2164 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.show',
          ),
          1 => 
          array (
            0 => 'setting',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.settings.update',
          ),
          1 => 
          array (
            0 => 'setting',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2211 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.assets',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2230 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.deployable',
          ),
          1 => 
          array (
            0 => 'statuslabel',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2240 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.show',
          ),
          1 => 
          array (
            0 => 'statuslabel',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.update',
          ),
          1 => 
          array (
            0 => 'statuslabel',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.statuslabels.destroy',
          ),
          1 => 
          array (
            0 => 'statuslabel',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2270 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.suppliers.show',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.suppliers.update',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.suppliers.destroy',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2304 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.user.eulas',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2364 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.assetlist',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2383 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.accessorieslist',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2398 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.email_assets',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2415 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.licenselist',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2431 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.restore',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2441 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.show',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.update',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.users.destroy',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2468 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.show',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.update',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.destroy',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2492 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.licenses.index',
          ),
          1 => 
          array (
            0 => 'kit_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.licenses.store',
          ),
          1 => 
          array (
            0 => 'kit_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2513 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.licenses.update',
          ),
          1 => 
          array (
            0 => 'kit_id',
            1 => 'license_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.licenses.destroy',
          ),
          1 => 
          array (
            0 => 'kit_id',
            1 => 'license_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2533 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.models.index',
          ),
          1 => 
          array (
            0 => 'kit_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.models.store',
          ),
          1 => 
          array (
            0 => 'kit_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2554 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.models.update',
          ),
          1 => 
          array (
            0 => 'kit_id',
            1 => 'model_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.models.destroy',
          ),
          1 => 
          array (
            0 => 'kit_id',
            1 => 'model_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2579 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.accessories.index',
          ),
          1 => 
          array (
            0 => 'kit_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.accessories.store',
          ),
          1 => 
          array (
            0 => 'kit_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2600 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.accessories.update',
          ),
          1 => 
          array (
            0 => 'kit_id',
            1 => 'accessory_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.accessories.destroy',
          ),
          1 => 
          array (
            0 => 'kit_id',
            1 => 'accessory_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2625 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.consumables.index',
          ),
          1 => 
          array (
            0 => 'kit_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.consumables.store',
          ),
          1 => 
          array (
            0 => 'kit_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2646 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.consumables.update',
          ),
          1 => 
          array (
            0 => 'kit_id',
            1 => 'consumable_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.kits.consumables.destroy',
          ),
          1 => 
          array (
            0 => 'kit_id',
            1 => 'consumable_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2778 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.files.index',
          ),
          1 => 
          array (
            0 => 'object_type',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2915 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.files.show',
          ),
          1 => 
          array (
            0 => 'object_type',
            1 => 'id',
            2 => 'file_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3043 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.files.store',
          ),
          1 => 
          array (
            0 => 'object_type',
            1 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3180 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.files.destroy',
          ),
          1 => 
          array (
            0 => 'object_type',
            1 => 'id',
            2 => 'file_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3236 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.checkout.show',
          ),
          1 => 
          array (
            0 => 'accessoryID',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3245 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.checkout.store',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3274 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.checkin.show',
            'backto' => NULL,
          ),
          1 => 
          array (
            0 => 'accessoryID',
            1 => 'backto',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.checkin.store',
            'backto' => NULL,
          ),
          1 => 
          array (
            0 => 'accessoryID',
            1 => 'backto',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3292 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'clone/accessories',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3301 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cCXge2RRSj5EeMvg',
          ),
          1 => 
          array (
            0 => 'accessoryId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.edit',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3326 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.show',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.update',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'accessories.destroy',
          ),
          1 => 
          array (
            0 => 'accessory',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3373 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.request-asset',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3389 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.request-asset.cancel',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3445 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account/request-item',
            'cancel_by_admin' => NULL,
            'requestingUser' => NULL,
          ),
          1 => 
          array (
            0 => 'itemType',
            1 => 'itemId',
            2 => 'cancel_by_admin',
            3 => 'requestingUser',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.signature.view',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3512 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.storedeula.download',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3539 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.accept.item',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.store-acceptance',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3590 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.backups.download',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3613 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.backups.destroy',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3642 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.backups.restore',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3665 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tEvRz1yMYhg0wyu6',
            'filename' => NULL,
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3694 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'groups.show',
          ),
          1 => 
          array (
            0 => 'group',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3708 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'groups.edit',
          ),
          1 => 
          array (
            0 => 'group',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3717 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'groups.update',
          ),
          1 => 
          array (
            0 => 'group',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'groups.destroy',
          ),
          1 => 
          array (
            0 => 'group',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3762 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'asset.audit.create',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'asset.audit.store',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3790 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'findbytag/hardware',
            'any' => NULL,
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3815 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'findbyserial/hardware',
            'any' => NULL,
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3848 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'clone/hardware',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3870 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.checkout.create',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3879 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.checkout.store',
          ),
          1 => 
          array (
            0 => 'assetId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3908 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.checkin.create',
            'backto' => NULL,
          ),
          1 => 
          array (
            0 => 'asset',
            1 => 'backto',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3917 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.checkin.store',
            'backto' => NULL,
          ),
          1 => 
          array (
            0 => 'assetId',
            1 => 'backto',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3934 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'label/hardware',
          ),
          1 => 
          array (
            0 => 'assetId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3947 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IQHeDBmgSCc13XCX',
          ),
          1 => 
          array (
            0 => 'assetId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3963 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'qr_code/hardware',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3979 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'barcode/hardware',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3995 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'restore/hardware',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4008 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.edit',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4018 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.show',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.update',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'hardware.destroy',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4040 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ht/assetTag',
            'any' => NULL,
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4081 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'maintenances.show',
          ),
          1 => 
          array (
            0 => 'maintenance',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4095 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'maintenances.edit',
          ),
          1 => 
          array (
            0 => 'maintenance',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'maintenances.update',
          ),
          1 => 
          array (
            0 => 'maintenance',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'maintenances.destroy',
          ),
          1 => 
          array (
            0 => 'maintenance',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4148 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'restore/manufacturer',
          ),
          1 => 
          array (
            0 => 'manufacturers_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4161 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manufacturers.edit',
          ),
          1 => 
          array (
            0 => 'manufacturer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4171 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manufacturers.show',
          ),
          1 => 
          array (
            0 => 'manufacturer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'manufacturers.update',
          ),
          1 => 
          array (
            0 => 'manufacturer',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'manufacturers.destroy',
          ),
          1 => 
          array (
            0 => 'manufacturer',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4217 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'models.clone.create',
          ),
          1 => 
          array (
            0 => 'model',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'models.clone.store',
          ),
          1 => 
          array (
            0 => 'model',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4239 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'custom_fields/model',
          ),
          1 => 
          array (
            0 => 'modelId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4253 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'view/model',
          ),
          1 => 
          array (
            0 => 'modelId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4269 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'models.restore.store',
          ),
          1 => 
          array (
            0 => 'modelID',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4282 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'models.edit',
          ),
          1 => 
          array (
            0 => 'model',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4292 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'models.show',
          ),
          1 => 
          array (
            0 => 'model',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'models.update',
          ),
          1 => 
          array (
            0 => 'model',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'models.destroy',
          ),
          1 => 
          array (
            0 => 'model',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4328 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'modal.show',
            'itemId' => NULL,
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'itemId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.checkout.show',
          ),
          1 => 
          array (
            0 => 'consumablesID',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.checkout.store',
          ),
          1 => 
          array (
            0 => 'consumablesID',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4401 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.clone.create',
          ),
          1 => 
          array (
            0 => 'consumable',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4415 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.edit',
          ),
          1 => 
          array (
            0 => 'consumable',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4425 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.show',
          ),
          1 => 
          array (
            0 => 'consumable',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.update',
          ),
          1 => 
          array (
            0 => 'consumable',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'consumables.destroy',
          ),
          1 => 
          array (
            0 => 'consumable',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'components.checkout.show',
          ),
          1 => 
          array (
            0 => 'componentID',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'components.checkout.store',
          ),
          1 => 
          array (
            0 => 'componentID',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4505 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'components.checkin.show',
            'backto' => NULL,
          ),
          1 => 
          array (
            0 => 'componentID',
            1 => 'backto',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'components.checkin.store',
            'backto' => NULL,
          ),
          1 => 
          array (
            0 => 'componentID',
            1 => 'backto',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4520 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'components.edit',
          ),
          1 => 
          array (
            0 => 'component',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4530 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'components.show',
          ),
          1 => 
          array (
            0 => 'component',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'components.update',
          ),
          1 => 
          array (
            0 => 'component',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'components.destroy',
          ),
          1 => 
          array (
            0 => 'component',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4557 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'companies.show',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4571 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'companies.edit',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4580 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'companies.update',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'companies.destroy',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4613 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.show',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4627 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.edit',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4636 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.update',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'categories.destroy',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4684 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fields.required',
          ),
          1 => 
          array (
            0 => 'fieldset_id',
            1 => 'field_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4719 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fields.optional',
          ),
          1 => 
          array (
            0 => 'fieldset_id',
            1 => 'field_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4767 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fields.disassociate',
          ),
          1 => 
          array (
            0 => 'field_id',
            1 => 'fieldset_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4810 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fieldsets.associate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4823 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fieldsets.edit',
          ),
          1 => 
          array (
            0 => 'fieldset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4833 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fieldsets.show',
          ),
          1 => 
          array (
            0 => 'fieldset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'fieldsets.update',
          ),
          1 => 
          array (
            0 => 'fieldset',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'fieldsets.destroy',
          ),
          1 => 
          array (
            0 => 'fieldset',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4859 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fields.edit',
          ),
          1 => 
          array (
            0 => 'field',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4868 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'fields.update',
          ),
          1 => 
          array (
            0 => 'field',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'fields.destroy',
          ),
          1 => 
          array (
            0 => 'field',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4909 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.clone.show',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'users.clone.store',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4926 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.restore.store',
          ),
          1 => 
          array (
            0 => 'userId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4944 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'unsuspend/user',
          ),
          1 => 
          array (
            0 => 'userId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4964 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.password',
          ),
          1 => 
          array (
            0 => 'userId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4977 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.print',
          ),
          1 => 
          array (
            0 => 'userId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4995 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.email',
          ),
          1 => 
          array (
            0 => 'userId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5007 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.edit',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5018 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'users.show',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'users.update',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'users.destroy',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5060 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.licenses.store',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5081 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.licenses.update',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'license_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5095 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.licenses.edit',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'license_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.licenses.detach',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'license_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5133 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.models.update',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'model_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.models.edit',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'model_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5156 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.models.detach',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'model_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5192 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.consumables.update',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'consumable_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5206 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.consumables.edit',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'consumable_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5215 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.consumables.detach',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'consumable_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.checkout.show',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'kits.checkout.store',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5269 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.accessories.update',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'accessory_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5283 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.accessories.edit',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'accessory_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5292 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.accessories.detach',
          ),
          1 => 
          array (
            0 => 'kit',
            1 => 'accessory_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5306 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.edit',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kits.show',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'kits.update',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'kits.destroy',
          ),
          1 => 
          array (
            0 => 'kit',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5351 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suppliers.show',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5365 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suppliers.edit',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5374 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suppliers.update',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'suppliers.destroy',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5410 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'statuslabels.show',
          ),
          1 => 
          array (
            0 => 'statuslabel',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5424 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'statuslabels.edit',
          ),
          1 => 
          array (
            0 => 'statuslabel',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5433 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'statuslabels.update',
          ),
          1 => 
          array (
            0 => 'statuslabel',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'statuslabels.destroy',
          ),
          1 => 
          array (
            0 => 'statuslabel',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5468 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'log.storedeula.download',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5511 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'depreciations.show',
          ),
          1 => 
          array (
            0 => 'depreciation',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5525 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'depreciations.edit',
          ),
          1 => 
          array (
            0 => 'depreciation',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5534 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'depreciations.update',
          ),
          1 => 
          array (
            0 => 'depreciation',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'depreciations.destroy',
          ),
          1 => 
          array (
            0 => 'depreciation',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5564 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'departments.show',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5578 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'departments.edit',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5587 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'departments.update',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'departments.destroy',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5618 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'log.signature.view',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5661 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'report-templates.show',
          ),
          1 => 
          array (
            0 => 'reportTemplate',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5675 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'report-templates.edit',
          ),
          1 => 
          array (
            0 => 'reportTemplate',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5684 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'report-templates.update',
          ),
          1 => 
          array (
            0 => 'reportTemplate',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'report-templates.destroy',
          ),
          1 => 
          array (
            0 => 'reportTemplate',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5728 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/unaccepted_assets',
            'deleted' => NULL,
          ),
          1 => 
          array (
            0 => 'deleted',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5754 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/unaccepted_assets_sent_reminder',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5778 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/unaccepted_assets_delete',
          ),
          1 => 
          array (
            0 => 'acceptanceId',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      5802 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports/export/unaccepted_assets',
            'deleted' => NULL,
          ),
          1 => 
          array (
            0 => 'deleted',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5975 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ui.files.show',
          ),
          1 => 
          array (
            0 => 'object_type',
            1 => 'id',
            2 => 'file_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ui.files.store',
          ),
          1 => 
          array (
            0 => 'object_type',
            1 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      6242 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ui.files.destroy',
          ),
          1 => 
          array (
            0 => 'object_type',
            1 => 'id',
            2 => 'file_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      6282 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scim.schemas',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6313 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scim.resourcetype',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6345 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scim.resource',
          ),
          1 => 
          array (
            0 => 'resourceType',
            1 => 'resourceObject',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6371 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scim.resources',
          ),
          1 => 
          array (
            0 => 'resourceType',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Qr1FDyUo4xj69pSf',
          ),
          1 => 
          array (
            0 => 'resourceType',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FQFnBZdZchNXp5ku',
          ),
          1 => 
          array (
            0 => 'resourceType',
            1 => 'resourceObject',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LHakJwSR4J040Kmp',
          ),
          1 => 
          array (
            0 => 'resourceType',
            1 => 'resourceObject',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9LgAR0wpxKbgeEcR',
          ),
          1 => 
          array (
            0 => 'resourceType',
            1 => 'resourceObject',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6421 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ib1G0nuzeiwnHBv8',
          ),
          1 => 
          array (
            0 => 'fallbackPlaceholder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6437 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cLhDy5IwDVJch5ot',
          ),
          1 => 
          array (
            0 => 'fallbackPlaceholder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6459 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wUDK3JUuBZSb3Z0U',
          ),
          1 => 
          array (
            0 => 'fallbackPlaceholder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'debugbar.openhandler' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/open',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@handle',
        'as' => 'debugbar.openhandler',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@handle',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.clockwork' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/clockwork/{id}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@clockwork',
        'as' => 'debugbar.clockwork',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@clockwork',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.assets.css' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/assets/stylesheets',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@css',
        'as' => 'debugbar.assets.css',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@css',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.assets.js' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/assets/javascript',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@js',
        'as' => 'debugbar.assets.js',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@js',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.cache.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '_debugbar/cache/{key}/{tags?}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\CacheController@delete',
        'as' => 'debugbar.cache.delete',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\CacheController@delete',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.queries.explain' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_debugbar/queries/explain',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\QueriesController@explain',
        'as' => 'debugbar.queries.explain',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\QueriesController@explain',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.token' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/token',
      'action' => 
      array (
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\AccessTokenController@issueToken',
        'as' => 'passport.token',
        'middleware' => 'throttle',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\AccessTokenController@issueToken',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.authorizations.authorize' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/authorize',
      'action' => 
      array (
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\AuthorizationController@authorize',
        'as' => 'passport.authorizations.authorize',
        'middleware' => 'web',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\AuthorizationController@authorize',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.token.refresh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/token/refresh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\TransientTokenController@refresh',
        'as' => 'passport.token.refresh',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\TransientTokenController@refresh',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.authorizations.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/authorize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\ApproveAuthorizationController@approve',
        'as' => 'passport.authorizations.approve',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\ApproveAuthorizationController@approve',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.authorizations.deny' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/authorize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\DenyAuthorizationController@deny',
        'as' => 'passport.authorizations.deny',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\DenyAuthorizationController@deny',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.tokens.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@forUser',
        'as' => 'passport.tokens.index',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@forUser',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.tokens.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/tokens/{token_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@destroy',
        'as' => 'passport.tokens.destroy',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@destroy',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.clients.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/clients',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\ClientController@forUser',
        'as' => 'passport.clients.index',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\ClientController@forUser',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.clients.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/clients',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\ClientController@store',
        'as' => 'passport.clients.store',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\ClientController@store',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.clients.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'oauth/clients/{client_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\ClientController@update',
        'as' => 'passport.clients.update',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\ClientController@update',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.clients.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/clients/{client_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\ClientController@destroy',
        'as' => 'passport.clients.destroy',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\ClientController@destroy',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.scopes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/scopes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\ScopeController@all',
        'as' => 'passport.scopes.index',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\ScopeController@all',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.personal.tokens.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/personal-access-tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@forUser',
        'as' => 'passport.personal.tokens.index',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@forUser',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.personal.tokens.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/personal-access-tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@store',
        'as' => 'passport.personal.tokens.store',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@store',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.personal.tokens.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/personal-access-tokens/{token_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@destroy',
        'as' => 'passport.personal.tokens.destroy',
        'controller' => 'Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@destroy',
        'namespace' => 'Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/update',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\HandleRequests\\HandleRequests@handleUpdate',
        'controller' => 'Livewire\\Mechanisms\\HandleRequests\\HandleRequests@handleUpdate',
        'as' => 'livewire.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hutaOzGZLN5cFHNQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.min.js',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@returnJavaScriptAsFile',
        'controller' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@returnJavaScriptAsFile',
        'as' => 'generated::hutaOzGZLN5cFHNQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lqziNWhtg12L4kSf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.min.js.map',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@maps',
        'controller' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@maps',
        'as' => 'generated::lqziNWhtg12L4kSf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.upload-file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/upload-file',
      'action' => 
      array (
        'uses' => 'Livewire\\Features\\SupportFileUploads\\FileUploadController@handle',
        'controller' => 'Livewire\\Features\\SupportFileUploads\\FileUploadController@handle',
        'as' => 'livewire.upload-file',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.preview-file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/preview-file/{filename}',
      'action' => 
      array (
        'uses' => 'Livewire\\Features\\SupportFileUploads\\FilePreviewController@handle',
        'controller' => 'Livewire\\Features\\SupportFileUploads\\FilePreviewController@handle',
        'as' => 'livewire.preview-file',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::luhhPS65gYoOS6a3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:394:"function () {
        return \\response()->json(
            [
                \'status\' => \'error\',
                \'message\' => \'404 endpoint not found. This is the base URL for the API and does not return anything itself. Please check the API reference at https://snipe-it.readme.io/reference to find a valid API endpoint.\',
                \'payload\' => null,
            ], 404);
    }";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000ae60000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::luhhPS65gYoOS6a3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.requested' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/account/requests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ProfileController@requestedAssets',
        'controller' => 'App\\Http\\Controllers\\Api\\ProfileController@requestedAssets',
        'namespace' => NULL,
        'prefix' => 'api/v1/account',
        'where' => 
        array (
        ),
        'as' => 'api.assets.requested',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.self.eulas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/account/eulas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ProfileController@eulas',
        'controller' => 'App\\Http\\Controllers\\Api\\ProfileController@eulas',
        'namespace' => NULL,
        'prefix' => 'api/v1/account',
        'where' => 
        array (
        ),
        'as' => 'api.self.eulas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.requests.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/account/request/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CheckoutRequest@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CheckoutRequest@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/account',
        'where' => 
        array (
        ),
        'as' => 'api.assets.requests.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.requests.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/account/request/{asset}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CheckoutRequest@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CheckoutRequest@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/account',
        'where' => 
        array (
        ),
        'as' => 'api.assets.requests.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.requestable' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/account/requestable/hardware',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@requestable',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@requestable',
        'namespace' => NULL,
        'prefix' => 'api/v1/account',
        'where' => 
        array (
        ),
        'as' => 'api.assets.requestable',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.personal-access-token.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/account/personal-access-tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ProfileController@createApiToken',
        'controller' => 'App\\Http\\Controllers\\Api\\ProfileController@createApiToken',
        'namespace' => NULL,
        'prefix' => 'api/v1/account',
        'where' => 
        array (
        ),
        'as' => 'api.personal-access-token.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.personal-access-token.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/account/personal-access-tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ProfileController@showApiTokens',
        'controller' => 'App\\Http\\Controllers\\Api\\ProfileController@showApiTokens',
        'namespace' => NULL,
        'prefix' => 'api/v1/account',
        'where' => 
        array (
        ),
        'as' => 'api.personal-access-token.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.personal-access-token.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/account/personal-access-tokens/{tokenId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ProfileController@deleteApiToken',
        'controller' => 'App\\Http\\Controllers\\Api\\ProfileController@deleteApiToken',
        'namespace' => NULL,
        'prefix' => 'api/v1/account',
        'where' => 
        array (
        ),
        'as' => 'api.personal-access-token.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.accessories.checkedout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/accessories/{accessory}/checkedout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AccessoriesController@checkedout',
        'controller' => 'App\\Http\\Controllers\\Api\\AccessoriesController@checkedout',
        'namespace' => NULL,
        'prefix' => 'api/v1/accessories',
        'where' => 
        array (
        ),
        'as' => 'api.accessories.checkedout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.accessories.checkout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/accessories/{accessory}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AccessoriesController@checkout',
        'controller' => 'App\\Http\\Controllers\\Api\\AccessoriesController@checkout',
        'namespace' => NULL,
        'prefix' => 'api/v1/accessories',
        'where' => 
        array (
        ),
        'as' => 'api.accessories.checkout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.accessories.checkin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/accessories/{accessory}/checkin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AccessoriesController@checkin',
        'controller' => 'App\\Http\\Controllers\\Api\\AccessoriesController@checkin',
        'namespace' => NULL,
        'prefix' => 'api/v1/accessories',
        'where' => 
        array (
        ),
        'as' => 'api.accessories.checkin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.accessories.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/accessories/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AccessoriesController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\AccessoriesController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/accessories',
        'where' => 
        array (
        ),
        'as' => 'api.accessories.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.accessories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.accessories.index',
        'uses' => 'App\\Http\\Controllers\\Api\\AccessoriesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AccessoriesController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.accessories.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.accessories.store',
        'uses' => 'App\\Http\\Controllers\\Api\\AccessoriesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AccessoriesController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.accessories.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/accessories/{accessory}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.accessories.show',
        'uses' => 'App\\Http\\Controllers\\Api\\AccessoriesController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\AccessoriesController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.accessories.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/accessories/{accessory}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.accessories.update',
        'uses' => 'App\\Http\\Controllers\\Api\\AccessoriesController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AccessoriesController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.accessories.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/accessories/{accessory}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.accessories.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\AccessoriesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\AccessoriesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.categories.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/categories/{item_type}/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CategoriesController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoriesController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/categories',
        'where' => 
        array (
        ),
        'as' => 'api.categories.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.categories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.categories.index',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoriesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoriesController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.categories.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.categories.store',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoriesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoriesController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.categories.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.categories.show',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoriesController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoriesController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.categories.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.categories.update',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoriesController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoriesController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.categories.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.categories.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoriesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoriesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.companies.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/companies/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompaniesController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\CompaniesController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/companies',
        'where' => 
        array (
        ),
        'as' => 'api.companies.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.companies.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.companies.index',
        'uses' => 'App\\Http\\Controllers\\Api\\CompaniesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompaniesController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.companies.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.companies.store',
        'uses' => 'App\\Http\\Controllers\\Api\\CompaniesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompaniesController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.companies.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/companies/{company}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.companies.show',
        'uses' => 'App\\Http\\Controllers\\Api\\CompaniesController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CompaniesController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.companies.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/companies/{company}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.companies.update',
        'uses' => 'App\\Http\\Controllers\\Api\\CompaniesController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CompaniesController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.companies.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/companies/{company}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.companies.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\CompaniesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CompaniesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.departments.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/departments/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DepartmentsController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\DepartmentsController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/departments',
        'where' => 
        array (
        ),
        'as' => 'api.departments.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.departments.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/departments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.departments.index',
        'uses' => 'App\\Http\\Controllers\\Api\\DepartmentsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\DepartmentsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.departments.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/departments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.departments.store',
        'uses' => 'App\\Http\\Controllers\\Api\\DepartmentsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DepartmentsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.departments.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/departments/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.departments.show',
        'uses' => 'App\\Http\\Controllers\\Api\\DepartmentsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\DepartmentsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.departments.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/departments/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.departments.update',
        'uses' => 'App\\Http\\Controllers\\Api\\DepartmentsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\DepartmentsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.departments.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/departments/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.departments.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\DepartmentsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\DepartmentsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.components.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/components/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ComponentsController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\ComponentsController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/components',
        'where' => 
        array (
        ),
        'as' => 'api.components.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.components.assets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/components/{component}/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ComponentsController@getAssets',
        'controller' => 'App\\Http\\Controllers\\Api\\ComponentsController@getAssets',
        'namespace' => NULL,
        'prefix' => 'api/v1/components',
        'where' => 
        array (
        ),
        'as' => 'api.components.assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.components.checkin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/components/{id}/checkin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ComponentsController@checkin',
        'controller' => 'App\\Http\\Controllers\\Api\\ComponentsController@checkin',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.components.checkin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.components.checkout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/components/{id}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ComponentsController@checkout',
        'controller' => 'App\\Http\\Controllers\\Api\\ComponentsController@checkout',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.components.checkout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.components.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/components',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.components.index',
        'uses' => 'App\\Http\\Controllers\\Api\\ComponentsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ComponentsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.components.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/components',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.components.store',
        'uses' => 'App\\Http\\Controllers\\Api\\ComponentsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\ComponentsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.components.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/components/{component}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.components.show',
        'uses' => 'App\\Http\\Controllers\\Api\\ComponentsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ComponentsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.components.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/components/{component}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.components.update',
        'uses' => 'App\\Http\\Controllers\\Api\\ComponentsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\ComponentsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.components.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/components/{component}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.components.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\ComponentsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\ComponentsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.consumables.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/consumables/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ConsumablesController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\ConsumablesController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/consumables',
        'where' => 
        array (
        ),
        'as' => 'api.consumables.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.consumables.show.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/consumables/{id}/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ConsumablesController@getDataView',
        'controller' => 'App\\Http\\Controllers\\Api\\ConsumablesController@getDataView',
        'namespace' => NULL,
        'prefix' => 'api/v1/consumables',
        'where' => 
        array (
        ),
        'as' => 'api.consumables.show.users',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.consumables.checkout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/consumables/{consumable}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ConsumablesController@checkout',
        'controller' => 'App\\Http\\Controllers\\Api\\ConsumablesController@checkout',
        'namespace' => NULL,
        'prefix' => 'api/v1/consumables',
        'where' => 
        array (
        ),
        'as' => 'api.consumables.checkout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.consumables.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/consumables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.consumables.index',
        'uses' => 'App\\Http\\Controllers\\Api\\ConsumablesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ConsumablesController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.consumables.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/consumables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.consumables.store',
        'uses' => 'App\\Http\\Controllers\\Api\\ConsumablesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\ConsumablesController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.consumables.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/consumables/{consumable}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.consumables.show',
        'uses' => 'App\\Http\\Controllers\\Api\\ConsumablesController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ConsumablesController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.consumables.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/consumables/{consumable}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.consumables.update',
        'uses' => 'App\\Http\\Controllers\\Api\\ConsumablesController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\ConsumablesController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.consumables.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/consumables/{consumable}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.consumables.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\ConsumablesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\ConsumablesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.depreciations.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/depreciations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.depreciations.index',
        'uses' => 'App\\Http\\Controllers\\Api\\DepreciationsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\DepreciationsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.depreciations.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/depreciations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.depreciations.store',
        'uses' => 'App\\Http\\Controllers\\Api\\DepreciationsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DepreciationsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.depreciations.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/depreciations/{depreciation_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.depreciations.show',
        'uses' => 'App\\Http\\Controllers\\Api\\DepreciationsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\DepreciationsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.depreciations.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/depreciations/{depreciation_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.depreciations.update',
        'uses' => 'App\\Http\\Controllers\\Api\\DepreciationsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\DepreciationsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.depreciations.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/depreciations/{depreciation_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.depreciations.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\DepreciationsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\DepreciationsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.depreciation-report.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/reports/depreciation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.depreciation-report.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customfields.order' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/fields/fieldsets/{id}/order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@postReorder',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@postReorder',
        'namespace' => NULL,
        'prefix' => 'api/v1/fields',
        'where' => 
        array (
        ),
        'as' => 'api.customfields.order',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customfields.associate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/fields/{field}/associate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@associate',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@associate',
        'namespace' => NULL,
        'prefix' => 'api/v1/fields',
        'where' => 
        array (
        ),
        'as' => 'api.customfields.associate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customfields.disassociate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/fields/{field}/disassociate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@disassociate',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@disassociate',
        'namespace' => NULL,
        'prefix' => 'api/v1/fields',
        'where' => 
        array (
        ),
        'as' => 'api.customfields.disassociate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customfields.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/fields',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.customfields.index',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customfields.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/fields',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.customfields.store',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customfields.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/fields/{field}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.customfields.show',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customfields.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/fields/{field}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.customfields.update',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customfields.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/fields/{field}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.customfields.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.fieldsets.fields' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/fieldsets/{fieldset}/fields',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@fields',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@fields',
        'namespace' => NULL,
        'prefix' => 'api/v1/fieldsets',
        'where' => 
        array (
        ),
        'as' => 'api.fieldsets.fields',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.fieldsets.fields-with-default-value' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/fieldsets/{fieldset}/fields/{model}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@fieldsWithDefaultValues',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@fieldsWithDefaultValues',
        'namespace' => NULL,
        'prefix' => 'api/v1/fieldsets',
        'where' => 
        array (
        ),
        'as' => 'api.fieldsets.fields-with-default-value',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.fieldsets.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/fieldsets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.fieldsets.index',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.fieldsets.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/fieldsets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.fieldsets.store',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.fieldsets.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/fieldsets/{fieldset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.fieldsets.show',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.fieldsets.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/fieldsets/{fieldset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.fieldsets.update',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.fieldsets.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/fieldsets/{fieldset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.fieldsets.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomFieldsetsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.groups.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.groups.index',
        'uses' => 'App\\Http\\Controllers\\Api\\GroupsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\GroupsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.groups.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.groups.store',
        'uses' => 'App\\Http\\Controllers\\Api\\GroupsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\GroupsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.groups.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/groups/{group}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.groups.show',
        'uses' => 'App\\Http\\Controllers\\Api\\GroupsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\GroupsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.groups.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/groups/{group}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.groups.update',
        'uses' => 'App\\Http\\Controllers\\Api\\GroupsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\GroupsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.groups.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/groups/{group}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.groups.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\GroupsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\GroupsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'assets.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.licenselist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/{asset_id}/licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@licenses',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@licenses',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.assets.licenselist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.show.bytag' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/bytag/{tag}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@showByTag',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@showByTag',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'assets.show.bytag',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.show.bytag' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/bytag/{any}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@showByTag',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@showByTag',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.assets.show.bytag',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.checkout.bytag' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware/bytag/{any}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@checkoutByTag',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@checkoutByTag',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.assets.checkout.bytag',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.asset.checkinbytagPath' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware/bytag/{any}/checkin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@checkinbytag',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@checkinbytag',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.asset.checkinbytagPath',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.asset.checkinbytag' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware/checkinbytag',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@checkinbytag',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@checkinbytag',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.asset.checkinbytag',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.show.byserial' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/byserial/{any}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@showBySerial',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@showBySerial',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.assets.show.byserial',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.list-upcoming' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/{action}/{upcoming_status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.assets.list-upcoming',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'action' => 'audit|audits|checkins',
        'upcoming_status' => 'due|overdue|due-or-overdue',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.asset.audit.legacy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware/audit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@audit',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@audit',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.asset.audit.legacy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.asset.audit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware/{asset}/audit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@audit',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@audit',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.asset.audit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.asset.checkin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware/{id}/checkin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@checkin',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@checkin',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.asset.checkin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.asset.checkout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware/{id}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@checkout',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@checkout',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.asset.checkout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware/{asset_id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@restore',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.assets.restore',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.assigned_assets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/{asset}/assigned/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@assignedAssets',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@assignedAssets',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.assets.assigned_assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.assigned_accessories' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/{asset}/assigned/accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@assignedAccessories',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@assignedAccessories',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.assets.assigned_accessories',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.assigned_components' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/{asset}/assigned/components',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@assignedComponents',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@assignedComponents',
        'namespace' => NULL,
        'prefix' => 'api/v1/hardware',
        'where' => 
        array (
        ),
        'as' => 'api.assets.assigned_components',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/hardware/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.assets.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.put-update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/hardware/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.assets.put-update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.assets.index',
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.assets.store',
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/hardware/{hardware}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.assets.show',
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/hardware/{hardware}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.assets.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.maintenances.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/maintenances',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.maintenances.index',
        'uses' => 'App\\Http\\Controllers\\Api\\MaintenancesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\MaintenancesController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.maintenances.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/maintenances',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.maintenances.store',
        'uses' => 'App\\Http\\Controllers\\Api\\MaintenancesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\MaintenancesController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.maintenances.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/maintenances/{maintenance}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.maintenances.show',
        'uses' => 'App\\Http\\Controllers\\Api\\MaintenancesController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\MaintenancesController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.maintenances.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/maintenances/{maintenance}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.maintenances.update',
        'uses' => 'App\\Http\\Controllers\\Api\\MaintenancesController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\MaintenancesController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.maintenances.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/maintenances/{maintenance}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.maintenances.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\MaintenancesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\MaintenancesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.imports.importFile' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/imports/process/{import}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ImportController@process',
        'controller' => 'App\\Http\\Controllers\\Api\\ImportController@process',
        'namespace' => NULL,
        'prefix' => 'api/v1/imports',
        'where' => 
        array (
        ),
        'as' => 'api.imports.importFile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.imports.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/imports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.imports.index',
        'uses' => 'App\\Http\\Controllers\\Api\\ImportController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ImportController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.imports.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/imports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.imports.store',
        'uses' => 'App\\Http\\Controllers\\Api\\ImportController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\ImportController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.imports.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/imports/{import}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.imports.show',
        'uses' => 'App\\Http\\Controllers\\Api\\ImportController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ImportController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.imports.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/imports/{import}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.imports.update',
        'uses' => 'App\\Http\\Controllers\\Api\\ImportController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\ImportController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.imports.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/imports/{import}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.imports.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\ImportController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\ImportController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.labels.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/labels/{name}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LabelsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\LabelsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/labels',
        'where' => 
        array (
        ),
        'as' => 'api.labels.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'name' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.labels.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/labels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LabelsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\LabelsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/labels',
        'where' => 
        array (
        ),
        'as' => 'api.labels.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.licenses.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/licenses/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LicensesController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\LicensesController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/licenses',
        'where' => 
        array (
        ),
        'as' => 'api.licenses.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.licenses.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.licenses.index',
        'uses' => 'App\\Http\\Controllers\\Api\\LicensesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\LicensesController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.licenses.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.licenses.store',
        'uses' => 'App\\Http\\Controllers\\Api\\LicensesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\LicensesController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.licenses.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/licenses/{license_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.licenses.show',
        'uses' => 'App\\Http\\Controllers\\Api\\LicensesController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\LicensesController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.licenses.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/licenses/{license_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.licenses.update',
        'uses' => 'App\\Http\\Controllers\\Api\\LicensesController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\LicensesController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.licenses.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/licenses/{license_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.licenses.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\LicensesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\LicensesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.licenses.seats.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/licenses/{license}/seats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.licenses.seats.index',
        'uses' => 'App\\Http\\Controllers\\Api\\LicenseSeatsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\LicenseSeatsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.licenses.seats.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/licenses/{license}/seats/{seat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.licenses.seats.show',
        'uses' => 'App\\Http\\Controllers\\Api\\LicenseSeatsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\LicenseSeatsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.licenses.seats.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/licenses/{license}/seats/{seat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.licenses.seats.update',
        'uses' => 'App\\Http\\Controllers\\Api\\LicenseSeatsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\LicenseSeatsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/locations/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/locations',
        'where' => 
        array (
        ),
        'as' => 'api.locations.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.viewusers' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/locations/{location}/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@getDataViewUsers',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@getDataViewUsers',
        'namespace' => NULL,
        'prefix' => 'api/v1/locations',
        'where' => 
        array (
        ),
        'as' => 'api.locations.viewusers',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.viewassets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/locations/{location}/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@assets',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@assets',
        'namespace' => NULL,
        'prefix' => 'api/v1/locations',
        'where' => 
        array (
        ),
        'as' => 'api.locations.viewassets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.assigned_assets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/locations/{location}/assigned/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@assignedAssets',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@assignedAssets',
        'namespace' => NULL,
        'prefix' => 'api/v1/locations',
        'where' => 
        array (
        ),
        'as' => 'api.locations.assigned_assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.assigned_accessories' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/locations/{location}/assigned/accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@assignedAccessories',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@assignedAccessories',
        'namespace' => NULL,
        'prefix' => 'api/v1/locations',
        'where' => 
        array (
        ),
        'as' => 'api.locations.assigned_accessories',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.locations.index',
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.locations.store',
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/locations/{location}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.locations.show',
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/locations/{location}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.locations.update',
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.locations.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/locations/{location}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.locations.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\LocationsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\LocationsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.manufacturers.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/manufacturers/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ManufacturersController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\ManufacturersController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/manufacturers',
        'where' => 
        array (
        ),
        'as' => 'api.manufacturers.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.manufacturers.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/manufacturers/{id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ManufacturersController@restore',
        'controller' => 'App\\Http\\Controllers\\Api\\ManufacturersController@restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/manufacturers',
        'where' => 
        array (
        ),
        'as' => 'api.manufacturers.restore',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.manufacturers.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/manufacturers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.manufacturers.index',
        'uses' => 'App\\Http\\Controllers\\Api\\ManufacturersController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ManufacturersController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.manufacturers.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/manufacturers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.manufacturers.store',
        'uses' => 'App\\Http\\Controllers\\Api\\ManufacturersController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\ManufacturersController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.manufacturers.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/manufacturers/{manufacturer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.manufacturers.show',
        'uses' => 'App\\Http\\Controllers\\Api\\ManufacturersController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ManufacturersController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.manufacturers.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/manufacturers/{manufacturer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.manufacturers.update',
        'uses' => 'App\\Http\\Controllers\\Api\\ManufacturersController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\ManufacturersController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.manufacturers.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/manufacturers/{manufacturer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.manufacturers.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\ManufacturersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\ManufacturersController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.models.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/models/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetModelsController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetModelsController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/models',
        'where' => 
        array (
        ),
        'as' => 'api.models.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.models.assets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/models/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetModelsController@assets',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetModelsController@assets',
        'namespace' => NULL,
        'prefix' => 'api/v1/models',
        'where' => 
        array (
        ),
        'as' => 'api.models.assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.models.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/models/{id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetModelsController@restore',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetModelsController@restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/models',
        'where' => 
        array (
        ),
        'as' => 'api.models.restore',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.models.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/models',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.models.index',
        'uses' => 'App\\Http\\Controllers\\Api\\AssetModelsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetModelsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.models.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/models',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.models.store',
        'uses' => 'App\\Http\\Controllers\\Api\\AssetModelsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetModelsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.models.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/models/{model}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.models.show',
        'uses' => 'App\\Http\\Controllers\\Api\\AssetModelsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetModelsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.models.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/models/{model}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.models.update',
        'uses' => 'App\\Http\\Controllers\\Api\\AssetModelsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetModelsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.models.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/models/{model}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.models.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\AssetModelsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetModelsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.notes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/notes/{asset}/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NotesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\NotesController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/notes',
        'where' => 
        array (
        ),
        'as' => 'api.notes.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.notes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/notes/{asset}/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NotesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\NotesController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/notes',
        'where' => 
        array (
        ),
        'as' => 'api.notes.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.ldaptest' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/ldaptest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
          3 => 'auth',
          4 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@ldaptest',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@ldaptest',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'api.settings.ldaptest',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.purgebarcodes' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/purge_barcodes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
          3 => 'auth',
          4 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@purgeBarcodes',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@purgeBarcodes',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'api.settings.purgebarcodes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.login_attempts' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/login-attempts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
          3 => 'auth',
          4 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@showLoginAttempts',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@showLoginAttempts',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'api.settings.login_attempts',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.ldaptestlogin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/ldaptestlogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
          3 => 'auth',
          4 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@ldaptestlogin',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@ldaptestlogin',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'api.settings.ldaptestlogin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.slacktest' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/slacktest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
          3 => 'auth',
          4 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@slacktest',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@slacktest',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'api.settings.slacktest',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.mailtest' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/mailtest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
          3 => 'auth',
          4 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@ajaxTestEmail',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@ajaxTestEmail',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'api.settings.mailtest',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.backups.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/backups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
          3 => 'auth',
          4 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@listBackups',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@listBackups',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'api.settings.backups.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.backups.latest' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/backups/download/latest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
          3 => 'auth',
          4 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@downloadLatestBackup',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@downloadLatestBackup',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'api.settings.backups.latest',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.backups.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/backups/download/{file}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
          3 => 'auth',
          4 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@downloadBackup',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@downloadBackup',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'api.settings.backups.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.settings.store',
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/{setting}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.settings.show',
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.settings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/settings/{setting}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.settings.update',
        'uses' => 'App\\Http\\Controllers\\Api\\SettingsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\SettingsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/statuslabels/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/statuslabels',
        'where' => 
        array (
        ),
        'as' => 'api.statuslabels.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.assets.byname' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/statuslabels/assets/name',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@getAssetCountByStatuslabel',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@getAssetCountByStatuslabel',
        'namespace' => NULL,
        'prefix' => 'api/v1/statuslabels',
        'where' => 
        array (
        ),
        'as' => 'api.statuslabels.assets.byname',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.assets.bytype' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/statuslabels/assets/type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@getAssetCountByMetaStatus',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@getAssetCountByMetaStatus',
        'namespace' => NULL,
        'prefix' => 'api/v1/statuslabels',
        'where' => 
        array (
        ),
        'as' => 'api.statuslabels.assets.bytype',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.assets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/statuslabels/{id}/assetlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@assets',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@assets',
        'namespace' => NULL,
        'prefix' => 'api/v1/statuslabels',
        'where' => 
        array (
        ),
        'as' => 'api.statuslabels.assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.deployable' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/statuslabels/{statuslabel}/deployable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@checkIfDeployable',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@checkIfDeployable',
        'namespace' => NULL,
        'prefix' => 'api/v1/statuslabels',
        'where' => 
        array (
        ),
        'as' => 'api.statuslabels.deployable',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/statuslabels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.statuslabels.index',
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/statuslabels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.statuslabels.store',
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/statuslabels/{statuslabel}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.statuslabels.show',
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/statuslabels/{statuslabel}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.statuslabels.update',
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.statuslabels.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/statuslabels/{statuslabel}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.statuslabels.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\StatuslabelsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.suppliers.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/suppliers/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuppliersController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\SuppliersController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/suppliers',
        'where' => 
        array (
        ),
        'as' => 'api.suppliers.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.suppliers.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.suppliers.index',
        'uses' => 'App\\Http\\Controllers\\Api\\SuppliersController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SuppliersController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.suppliers.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.suppliers.store',
        'uses' => 'App\\Http\\Controllers\\Api\\SuppliersController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\SuppliersController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.suppliers.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/suppliers/{supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.suppliers.show',
        'uses' => 'App\\Http\\Controllers\\Api\\SuppliersController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\SuppliersController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.suppliers.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/suppliers/{supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.suppliers.update',
        'uses' => 'App\\Http\\Controllers\\Api\\SuppliersController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\SuppliersController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.suppliers.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/suppliers/{supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.suppliers.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\SuppliersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\SuppliersController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.selectlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/users/selectlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@selectlist',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@selectlist',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.selectlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.ldapsync' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/users/ldapsync',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@syncLdapUsers',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@syncLdapUsers',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.ldapsync',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.two_factor_reset' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/users/two_factor_reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@postTwoFactorReset',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@postTwoFactorReset',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.two_factor_reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.me' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/users/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@getCurrentUserInfo',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@getCurrentUserInfo',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.me',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.user.eulas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/users/{user}/eulas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@eulas',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@eulas',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.user.eulas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/users/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@getDatatable',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@getDatatable',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.list',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.assetlist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/users/{user}/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@assets',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@assets',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.assetlist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.email_assets' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/users/{user}/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@emailAssetList',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@emailAssetList',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.email_assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.accessorieslist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/users/{user}/accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@accessories',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@accessories',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.accessorieslist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.licenselist' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/users/{user}/licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@licenses',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@licenses',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.licenselist',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/users/{user}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@restore',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/users',
        'where' => 
        array (
        ),
        'as' => 'api.users.restore',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.users.index',
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.users.store',
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.users.show',
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.users.update',
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.users.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.users.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\UsersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\UsersController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/kits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.kits.index',
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/kits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.kits.store',
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/kits/{kit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.kits.show',
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/kits/{kit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.kits.update',
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/kits/{kit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'as' => 'api.kits.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.licenses.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/kits/{kit_id}/licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@indexLicenses',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@indexLicenses',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.licenses.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.licenses.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/kits/{kit_id}/licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@storeLicense',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@storeLicense',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.licenses.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.licenses.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/kits/{kit_id}/licenses/{license_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@updateLicense',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@updateLicense',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.licenses.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.licenses.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/kits/{kit_id}/licenses/{license_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@detachLicense',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@detachLicense',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.licenses.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.models.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/kits/{kit_id}/models',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@indexModels',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@indexModels',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.models.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.models.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/kits/{kit_id}/models',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@storeModel',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@storeModel',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.models.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.models.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/kits/{kit_id}/models/{model_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@updateModels',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@updateModels',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.models.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.models.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/kits/{kit_id}/models/{model_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@detachModels',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@detachModels',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.models.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.accessories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/kits/{kit_id}/accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@indexAccessories',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@indexAccessories',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.accessories.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.accessories.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/kits/{kit_id}/accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@storeAccessory',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@storeAccessory',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.accessories.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.accessories.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/kits/{kit_id}/accessories/{accessory_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@updateAccessory',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@updateAccessory',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.accessories.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.accessories.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/kits/{kit_id}/accessories/{accessory_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@detachAccessory',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@detachAccessory',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.accessories.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.consumables.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/kits/{kit_id}/consumables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@indexConsumables',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@indexConsumables',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.consumables.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.consumables.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/kits/{kit_id}/consumables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@storeConsumable',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@storeConsumable',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.consumables.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.consumables.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/kits/{kit_id}/consumables/{consumable_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@updateConsumable',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@updateConsumable',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.consumables.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.kits.consumables.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/kits/{kit_id}/consumables/{consumable_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@detachConsumable',
        'controller' => 'App\\Http\\Controllers\\Api\\PredefinedKitsController@detachConsumable',
        'namespace' => NULL,
        'prefix' => 'api/v1/kits/{kit_id}',
        'where' => 
        array (
        ),
        'as' => 'api.kits.consumables.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.activity.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/reports/activity',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ReportsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ReportsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/reports',
        'where' => 
        array (
        ),
        'as' => 'api.activity.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HxdcYQ97CTNRgaGv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/version',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:404:"function () {
            return \\response()->json(
                [
                    \'version\' => \\config(\'version.app_version\'),
                    \'build_version\' => \\config(\'version.build_version\'),
                    \'hash_version\' => \\config(\'version.hash_version\'),
                    \'full_version\' => \\config(\'version.full_app_version\')
                ]
            );
        }";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e390000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::HxdcYQ97CTNRgaGv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wUDK3JUuBZSb3Z0U' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/{fallbackPlaceholder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:352:"function () {
            return \\response()->json(
                [
                    \'status\' => \'error\',
                    \'message\' => \'404 endpoint not found. Please check the API reference at https://snipe-it.readme.io/reference to find a valid API endpoint.\',
                    \'payload\' => null,
                ], 404);
        }";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e6a0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::wUDK3JUuBZSb3Z0U',
      ),
      'fallback' => true,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'fallbackPlaceholder' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.assets.labels' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/hardware/labels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AssetsController@getLabels',
        'controller' => 'App\\Http\\Controllers\\Api\\AssetsController@getLabels',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.assets.labels',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.files.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/{object_type}/{id}/files',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UploadedFilesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\UploadedFilesController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.files.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'object_type' => 'accessories|audits|assets|components|consumables|hardware|licenses|locations|maintenances|models|users',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.files.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/{object_type}/{id}/files/{file_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UploadedFilesController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\UploadedFilesController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.files.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'object_type' => 'accessories|audits|assets|components|consumables|hardware|licenses|locations|maintenances|models|users',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.files.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/{object_type}/{id}/files',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UploadedFilesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\UploadedFilesController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.files.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'object_type' => 'accessories|audits|assets|components|consumables|hardware|licenses|locations|maintenances|models|users',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.files.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/{object_type}/{id}/files/{file_id}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'api',
          2 => 'api-throttle:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UploadedFilesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\UploadedFilesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.files.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'object_type' => 'accessories|assets|components|consumables|hardware|licenses|locations|maintenances|models|users',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.bulkaudit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/bulkaudit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@quickScan',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@quickScan',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'assets.bulkaudit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:401:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:185:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
            $trail->parent(\'hardware.index\')
                ->push(\\trans(\'general.bulkaudit\'), \\route(\'asset.import-history\'))
            ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e720000000000000000";}";s:4:"hash";s:44:"xAo4yuzetXb+yQsleD4KGeNHkMdnx+UNoSq5yQb38tY=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware/quickscancheckin' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/quickscancheckin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@quickScanCheckin',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@quickScanCheckin',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware/quickscancheckin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:398:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:182:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
            $trail->parent(\'hardware.index\')
                ->push(\'Quickscan Checkin\', \\route(\'hardware/quickscancheckin\'))
            ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e720000000000000000";}";s:4:"hash";s:44:"hXjlL3Ta2M1G7gQy4O2yW7Vn4wvwT2hwEjhYKBteyag=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.requested' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/requested',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getRequestedIndex',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getRequestedIndex',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'assets.requested',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:412:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:196:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
            $trail->parent(\'hardware.index\')
                ->push(\\trans(\'admin/hardware/general.requested\'), \\route(\'assets.requested\'))
            ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e720000000000000000";}";s:4:"hash";s:44:"saF18byTYLK50VBvZxYeCSV7jBpJ1+kTh1RKwt4836k=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.audit.due' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/audit/due',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@dueForAudit',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@dueForAudit',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'assets.audit.due',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:533:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:317:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
            $trail->parent(\'hardware.index\')
                ->push(\\trans_choice(\'general.audit_due_days\', \\App\\Models\\Setting::getSettings()->audit_warning_days, [\'days\' => \\App\\Models\\Setting::getSettings()->audit_warning_days]), \\route(\'assets.audit.due\'))
            ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e720000000000000000";}";s:4:"hash";s:44:"Apt9IIJ57n0b+dh2sk/1BQ19VuGAHeoxTvLWGbhR78w=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.checkins.due' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/checkins/due',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@dueForCheckin',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@dueForCheckin',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'assets.checkins.due',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:531:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:315:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
            $trail->parent(\'hardware.index\')
                ->push(\\trans_choice(\'general.checkin_due_days\', \\App\\Models\\Setting::getSettings()->due_checkin_days, [\'days\' => \\App\\Models\\Setting::getSettings()->due_checkin_days]), \\route(\'assets.audit.due\'))
            ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e720000000000000000";}";s:4:"hash";s:44:"VTUHikOax9LTIeTnRyiotTvYXvS/WtPSqSETOyGn6vc=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'asset.audit.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{asset}/audit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@audit',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@audit',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'asset.audit.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:398:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:182:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, \\App\\Models\\Asset $asset) =>
            $trail->parent(\'hardware.show\', $asset)
                ->push(\\trans(\'general.audit\'))
            ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e720000000000000000";}";s:4:"hash";s:44:"+U5C+RK/GHkpOT36Ap2MgGnb1ucbD/Dp5k11I9J/dos=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'asset.audit.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/{asset}/audit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@auditStore',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@auditStore',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'asset.audit.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'asset.import-history' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getImportHistory',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getImportHistory',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'asset.import-history',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:410:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:194:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
                $trail->parent(\'hardware.index\')
                ->push(\\trans(\'general.import-history\'), \\route(\'asset.import-history\'))
            ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e7a0000000000000000";}";s:4:"hash";s:44:"7uYhoaJUfPJuHqNaoCFzjLnkkwIvcAguxD85CMyYBqo=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'asset.process-import-history' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@postImportHistory',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@postImportHistory',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'asset.process-import-history',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'findbytag/hardware' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/bytag/{any?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getAssetByTag',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getAssetByTag',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'findbytag/hardware',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'findbyserial/hardware' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/byserial/{any?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getAssetBySerial',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getAssetBySerial',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'findbyserial/hardware',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'clone/hardware' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{asset}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getClone',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getClone',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'clone/hardware',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'label/hardware' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{assetId}/label',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getLabel',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getLabel',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'label/hardware',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.checkout.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{asset}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetCheckoutController@create',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetCheckoutController@create',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware.checkout.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:442:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:226:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, \\App\\Models\\Asset $asset) =>
            $trail->parent(\'hardware.show\', $asset)
                ->push(\\trans(\'admin/hardware/general.checkout\'), \\route(\'hardware.index\'))
            ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e7e0000000000000000";}";s:4:"hash";s:44:"deWPNyZCZnWWo/BJTZeABfz/WMrhXSDJE+AwymmJVyM=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.checkout.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/{assetId}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetCheckoutController@store',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetCheckoutController@store',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware.checkout.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.checkin.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{asset}/checkin/{backto?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetCheckinController@create',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetCheckinController@create',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware.checkin.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:429:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:213:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, \\App\\Models\\Asset $asset) =>
        $trail->parent(\'hardware.show\', $asset)
            ->push(\\trans(\'admin/hardware/general.checkin\'), \\route(\'hardware.index\'))
        ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e810000000000000000";}";s:4:"hash";s:44:"BRuk4fd7EAPux6JjH6LyQOaWXxhqIXbC6PR/vSqUVC8=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.checkin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/{assetId}/checkin/{backto?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetCheckinController@store',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetCheckinController@store',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware.checkin.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IQHeDBmgSCc13XCX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{assetId}/view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:99:"function ($assetId) {
            return \\redirect()->route(\'hardware.show\', $assetId);
        }";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e810000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'generated::IQHeDBmgSCc13XCX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'qr_code/hardware' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{asset}/qr_code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getQrCode',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getQrCode',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'qr_code/hardware',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'barcode/hardware' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{asset}/barcode',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getBarCode',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getBarCode',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'barcode/hardware',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'restore/hardware' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/{asset}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getRestore',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getRestore',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'restore/hardware',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'hardware/bulkedit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/bulkedit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@edit',
        'controller' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@edit',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware/bulkedit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware/bulkdelete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/bulkdelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@destroy',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware/bulkdelete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware/bulkrestore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/bulkrestore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@restore',
        'controller' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@restore',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware/bulkrestore',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware/bulksave' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/bulksave',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@update',
        'controller' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@update',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware/bulksave',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.bulkcheckout.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/bulkcheckout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@showCheckout',
        'controller' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@showCheckout',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware.bulkcheckout.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:414:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:198:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
            $trail->parent(\'hardware.index\')
                ->push(\\trans(\'admin/hardware/general.bulk_checkout\'), \\route(\'hardware.index\'))
            ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e8c0000000000000000";}";s:4:"hash";s:44:"wYNH7w2BTAkYZaegpHIVl1JpoKB6dyvC9Aa1I7oeCEY=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.bulkcheckout.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware/bulkcheckout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@storeCheckout',
        'controller' => 'App\\Http\\Controllers\\Assets\\BulkAssetsController@storeCheckout',
        'namespace' => NULL,
        'prefix' => '/hardware',
        'where' => 
        array (
        ),
        'as' => 'hardware.bulkcheckout.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'hardware.index',
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@index',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'hardware.create',
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@create',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hardware',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'hardware.store',
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@store',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'hardware.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'hardware.show',
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@show',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'hardware.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hardware/{asset}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'hardware.edit',
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@edit',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'hardware.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'hardware/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'hardware.update',
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@update',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'hardware.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'hardware/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'hardware.destroy',
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'maintenances.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'maintenances',
      'action' => 
      array (
        'middleware' => 'web',
        'as' => 'maintenances.index',
        'uses' => 'App\\Http\\Controllers\\MaintenancesController@index',
        'controller' => 'App\\Http\\Controllers\\MaintenancesController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'maintenances.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'maintenances/create',
      'action' => 
      array (
        'middleware' => 'web',
        'as' => 'maintenances.create',
        'uses' => 'App\\Http\\Controllers\\MaintenancesController@create',
        'controller' => 'App\\Http\\Controllers\\MaintenancesController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'maintenances.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'maintenances',
      'action' => 
      array (
        'middleware' => 'web',
        'as' => 'maintenances.store',
        'uses' => 'App\\Http\\Controllers\\MaintenancesController@store',
        'controller' => 'App\\Http\\Controllers\\MaintenancesController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'maintenances.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'maintenances/{maintenance}',
      'action' => 
      array (
        'middleware' => 'web',
        'as' => 'maintenances.show',
        'uses' => 'App\\Http\\Controllers\\MaintenancesController@show',
        'controller' => 'App\\Http\\Controllers\\MaintenancesController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'maintenances.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'maintenances/{maintenance}/edit',
      'action' => 
      array (
        'middleware' => 'web',
        'as' => 'maintenances.edit',
        'uses' => 'App\\Http\\Controllers\\MaintenancesController@edit',
        'controller' => 'App\\Http\\Controllers\\MaintenancesController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'maintenances.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'maintenances/{maintenance}',
      'action' => 
      array (
        'middleware' => 'web',
        'as' => 'maintenances.update',
        'uses' => 'App\\Http\\Controllers\\MaintenancesController@update',
        'controller' => 'App\\Http\\Controllers\\MaintenancesController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'maintenances.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'maintenances/{maintenance}',
      'action' => 
      array (
        'middleware' => 'web',
        'as' => 'maintenances.destroy',
        'uses' => 'App\\Http\\Controllers\\MaintenancesController@destroy',
        'controller' => 'App\\Http\\Controllers\\MaintenancesController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ht/assetTag' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ht/{any?}',
      'action' => 
      array (
        'middleware' => 'web',
        'uses' => 'App\\Http\\Controllers\\Assets\\AssetsController@getAssetByTag',
        'controller' => 'App\\Http\\Controllers\\Assets\\AssetsController@getAssetByTag',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ht/assetTag',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'models.clone.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'models/{model}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@getClone',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@getClone',
        'namespace' => NULL,
        'prefix' => '/models',
        'where' => 
        array (
        ),
        'as' => 'models.clone.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:376:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:160:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'models.index\')
            ->push(\\trans(\'admin/models/table.clone\'), \\route(\'models.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000e9d0000000000000000";}";s:4:"hash";s:44:"LsynNF7fULEolL5S9KB2Edn6p4yfVzFdVcutYLEKXzk=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'models.clone.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'models/{model}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@postCreate',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@postCreate',
        'namespace' => NULL,
        'prefix' => '/models',
        'where' => 
        array (
        ),
        'as' => 'models.clone.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'view/model' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'models/{modelId}/view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@getView',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@getView',
        'namespace' => NULL,
        'prefix' => '/models',
        'where' => 
        array (
        ),
        'as' => 'view/model',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'models.restore.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'models/{modelID}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@getRestore',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@getRestore',
        'namespace' => NULL,
        'prefix' => '/models',
        'where' => 
        array (
        ),
        'as' => 'models.restore.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'custom_fields/model' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'models/{modelId}/custom_fields',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@getCustomFields',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@getCustomFields',
        'namespace' => NULL,
        'prefix' => '/models',
        'where' => 
        array (
        ),
        'as' => 'custom_fields/model',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'models.bulkedit.index' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'models/bulkedit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\BulkAssetModelsController@edit',
        'controller' => 'App\\Http\\Controllers\\BulkAssetModelsController@edit',
        'namespace' => NULL,
        'prefix' => '/models',
        'where' => 
        array (
        ),
        'as' => 'models.bulkedit.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'models.bulkedit.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'models/bulksave',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\BulkAssetModelsController@update',
        'controller' => 'App\\Http\\Controllers\\BulkAssetModelsController@update',
        'namespace' => NULL,
        'prefix' => '/models',
        'where' => 
        array (
        ),
        'as' => 'models.bulkedit.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'models.bulkdelete.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'models/bulkdelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\BulkAssetModelsController@destroy',
        'controller' => 'App\\Http\\Controllers\\BulkAssetModelsController@destroy',
        'namespace' => NULL,
        'prefix' => '/models',
        'where' => 
        array (
        ),
        'as' => 'models.bulkdelete.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'models.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'models',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'models.index',
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@index',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'models.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'models/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'models.create',
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@create',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'models.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'models',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'models.store',
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@store',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'models.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'models/{model}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'models.show',
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@show',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'models.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'models/{model}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'models.edit',
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@edit',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'models.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'models/{model}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'models.update',
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@update',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'models.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'models/{model}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'models.destroy',
        'uses' => 'App\\Http\\Controllers\\AssetModelsController@destroy',
        'controller' => 'App\\Http\\Controllers\\AssetModelsController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.checkout.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'accessories/{accessoryID}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoryCheckoutController@create',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoryCheckoutController@create',
        'namespace' => NULL,
        'prefix' => '/accessories',
        'where' => 
        array (
        ),
        'as' => 'accessories.checkout.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.checkout.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'accessories/{accessory}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoryCheckoutController@store',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoryCheckoutController@store',
        'namespace' => NULL,
        'prefix' => '/accessories',
        'where' => 
        array (
        ),
        'as' => 'accessories.checkout.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.checkin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'accessories/{accessoryID}/checkin/{backto?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoryCheckinController@create',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoryCheckinController@create',
        'namespace' => NULL,
        'prefix' => '/accessories',
        'where' => 
        array (
        ),
        'as' => 'accessories.checkin.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.checkin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'accessories/{accessoryID}/checkin/{backto?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoryCheckinController@store',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoryCheckinController@store',
        'namespace' => NULL,
        'prefix' => '/accessories',
        'where' => 
        array (
        ),
        'as' => 'accessories.checkin.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'clone/accessories' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'accessories/{accessory}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@getClone',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@getClone',
        'namespace' => NULL,
        'prefix' => '/accessories',
        'where' => 
        array (
        ),
        'as' => 'clone/accessories',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cCXge2RRSj5EeMvg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'accessories/{accessoryId}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@postCreate',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@postCreate',
        'namespace' => NULL,
        'prefix' => '/accessories',
        'where' => 
        array (
        ),
        'as' => 'generated::cCXge2RRSj5EeMvg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'accessories.index',
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@index',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'accessories/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'accessories.create',
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@create',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'accessories.store',
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@store',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'accessories/{accessory}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'accessories.show',
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@show',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'accessories/{accessory}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'accessories.edit',
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@edit',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'accessories/{accessory}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'accessories.update',
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@update',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessories.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'accessories/{accessory}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'accessories.destroy',
        'uses' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Accessories\\AccessoriesController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'clone/license' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'licenses/{licenseId}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@getClone',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@getClone',
        'namespace' => NULL,
        'prefix' => '/licenses',
        'where' => 
        array (
        ),
        'as' => 'clone/license',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.freecheckout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'licenses/{licenseId}/freecheckout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@getFreeLicense',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@getFreeLicense',
        'namespace' => NULL,
        'prefix' => '/licenses',
        'where' => 
        array (
        ),
        'as' => 'licenses.freecheckout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.checkout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'licenses/{license}/checkout/{seatId?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckoutController@create',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckoutController@create',
        'namespace' => NULL,
        'prefix' => '/licenses',
        'where' => 
        array (
        ),
        'as' => 'licenses.checkout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:434:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:218:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, \\App\\Models\\License $license) =>
        $trail->parent(\'licenses.show\', $license)
            ->push(\\trans(\'general.checkout\'), \\route(\'licenses.checkout\', $license))
        ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000ebb0000000000000000";}";s:4:"hash";s:44:"FMwR7j+YfdCyHL/IKd4NvSlPk4tkW2AWQQXJ/Lp9sm4=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9ydZpFMQeZ9viyLe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'licenses/{licenseId}/checkout/{seatId?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckoutController@store',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckoutController@store',
        'namespace' => NULL,
        'prefix' => '/licenses',
        'where' => 
        array (
        ),
        'as' => 'generated::9ydZpFMQeZ9viyLe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.checkin' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'licenses/{licenseSeat}/checkin/{backto?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckinController@create',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckinController@create',
        'namespace' => NULL,
        'prefix' => '/licenses',
        'where' => 
        array (
        ),
        'as' => 'licenses.checkin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:457:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:241:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, \\App\\Models\\LicenseSeat $licenseSeat) =>
        $trail->parent(\'licenses.show\', $licenseSeat->license)
            ->push(\\trans(\'general.checkin\'), \\route(\'licenses.checkin\', $licenseSeat))
        ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000ebd0000000000000000";}";s:4:"hash";s:44:"oV6e356lSXeXOzXRWr4MErwDnAtkfTtQcJpwjL0KqxA=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.checkin.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'licenses/{licenseId}/checkin/{backto?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckinController@store',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckinController@store',
        'namespace' => NULL,
        'prefix' => '/licenses',
        'where' => 
        array (
        ),
        'as' => 'licenses.checkin.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.bulkcheckin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'licenses/{licenseId}/bulkcheckin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckinController@bulkCheckin',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckinController@bulkCheckin',
        'namespace' => NULL,
        'prefix' => '/licenses',
        'where' => 
        array (
        ),
        'as' => 'licenses.bulkcheckin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.bulkcheckout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'licenses/{licenseId}/bulkcheckout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckoutController@bulkCheckout',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicenseCheckoutController@bulkCheckout',
        'namespace' => NULL,
        'prefix' => '/licenses',
        'where' => 
        array (
        ),
        'as' => 'licenses.bulkcheckout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'licenses/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@getExportLicensesCsv',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@getExportLicensesCsv',
        'namespace' => NULL,
        'prefix' => '/licenses',
        'where' => 
        array (
        ),
        'as' => 'licenses.export',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'licenses.index',
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@index',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'licenses/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'licenses.create',
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@create',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'licenses.store',
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@store',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'licenses/{license}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'licenses.show',
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@show',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'licenses/{license}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'licenses.edit',
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@edit',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'licenses/{license}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'licenses.update',
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@update',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'licenses.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'licenses/{license}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'licenses.destroy',
        'uses' => 'App\\Http\\Controllers\\Licenses\\LicensesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Licenses\\LicensesController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.bulkdelete.show' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'locations/bulkdelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationsController@postBulkDelete',
        'controller' => 'App\\Http\\Controllers\\LocationsController@postBulkDelete',
        'namespace' => NULL,
        'prefix' => '/locations',
        'where' => 
        array (
        ),
        'as' => 'locations.bulkdelete.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.bulkdelete.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'locations/bulkedit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationsController@postBulkDeleteStore',
        'controller' => 'App\\Http\\Controllers\\LocationsController@postBulkDeleteStore',
        'namespace' => NULL,
        'prefix' => '/locations',
        'where' => 
        array (
        ),
        'as' => 'locations.bulkdelete.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'locations/{location}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationsController@postRestore',
        'controller' => 'App\\Http\\Controllers\\LocationsController@postRestore',
        'namespace' => NULL,
        'prefix' => '/locations',
        'where' => 
        array (
        ),
        'as' => 'locations.restore',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'clone/location' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'locations/{locationId}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationsController@getClone',
        'controller' => 'App\\Http\\Controllers\\LocationsController@getClone',
        'namespace' => NULL,
        'prefix' => '/locations',
        'where' => 
        array (
        ),
        'as' => 'clone/location',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.print_assigned' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'locations/{locationId}/printassigned',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationsController@print_assigned',
        'controller' => 'App\\Http\\Controllers\\LocationsController@print_assigned',
        'namespace' => NULL,
        'prefix' => '/locations',
        'where' => 
        array (
        ),
        'as' => 'locations.print_assigned',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.print_all_assigned' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'locations/{locationId}/printallassigned',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationsController@print_all_assigned',
        'controller' => 'App\\Http\\Controllers\\LocationsController@print_all_assigned',
        'namespace' => NULL,
        'prefix' => '/locations',
        'where' => 
        array (
        ),
        'as' => 'locations.print_all_assigned',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'locations.index',
        'uses' => 'App\\Http\\Controllers\\LocationsController@index',
        'controller' => 'App\\Http\\Controllers\\LocationsController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'locations/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'locations.create',
        'uses' => 'App\\Http\\Controllers\\LocationsController@create',
        'controller' => 'App\\Http\\Controllers\\LocationsController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'locations.store',
        'uses' => 'App\\Http\\Controllers\\LocationsController@store',
        'controller' => 'App\\Http\\Controllers\\LocationsController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'locations/{location}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'locations.show',
        'uses' => 'App\\Http\\Controllers\\LocationsController@show',
        'controller' => 'App\\Http\\Controllers\\LocationsController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'locations.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'locations/{location}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'locations.edit',
        'uses' => 'App\\Http\\Controllers\\LocationsController@edit',
        'controller' => 'App\\Http\\Controllers\\LocationsController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'locations.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'locations/{location}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'locations.update',
        'uses' => 'App\\Http\\Controllers\\LocationsController@update',
        'controller' => 'App\\Http\\Controllers\\LocationsController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'locations.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'locations/{location}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'locations.destroy',
        'uses' => 'App\\Http\\Controllers\\LocationsController@destroy',
        'controller' => 'App\\Http\\Controllers\\LocationsController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.checkout.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'consumables/{consumablesID}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumableCheckoutController@create',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumableCheckoutController@create',
        'namespace' => NULL,
        'prefix' => '/consumables',
        'where' => 
        array (
        ),
        'as' => 'consumables.checkout.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.checkout.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'consumables/{consumablesID}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumableCheckoutController@store',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumableCheckoutController@store',
        'namespace' => NULL,
        'prefix' => '/consumables',
        'where' => 
        array (
        ),
        'as' => 'consumables.checkout.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.clone.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'consumables/{consumable}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@clone',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@clone',
        'namespace' => NULL,
        'prefix' => '/consumables',
        'where' => 
        array (
        ),
        'as' => 'consumables.clone.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'consumables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'consumables.index',
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@index',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'consumables/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'consumables.create',
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@create',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'consumables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'consumables.store',
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@store',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'consumables/{consumable}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'consumables.show',
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@show',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'consumables/{consumable}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'consumables.edit',
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@edit',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'consumables/{consumable}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'consumables.update',
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@update',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'consumables.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'consumables/{consumable}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'consumables.destroy',
        'uses' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Consumables\\ConsumablesController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fields.required' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'fields/required/{fieldset_id}/{field_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@makeFieldRequired',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@makeFieldRequired',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
        'as' => 'fields.required',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fields.optional' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'fields/optional/{fieldset_id}/{field_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@makeFieldOptional',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@makeFieldOptional',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
        'as' => 'fields.optional',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fields.disassociate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'fields/{field_id}/fieldset/{fieldset_id}/disassociate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomFieldsController@deleteFieldFromFieldset',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsController@deleteFieldFromFieldset',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
        'as' => 'fields.disassociate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fieldsets.associate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'fields/fieldsets/{id}/associate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@associate',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@associate',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
        'as' => 'fieldsets.associate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fieldsets.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'fields/fieldsets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fieldsets.index',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@index',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@index',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fieldsets.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'fields/fieldsets/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fieldsets.create',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@create',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@create',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fieldsets.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'fields/fieldsets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fieldsets.store',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@store',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@store',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fieldsets.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'fields/fieldsets/{fieldset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fieldsets.show',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@show',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@show',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fieldsets.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'fields/fieldsets/{fieldset}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fieldsets.edit',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@edit',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@edit',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fieldsets.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'fields/fieldsets/{fieldset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fieldsets.update',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@update',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@update',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fieldsets.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'fields/fieldsets/{fieldset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fieldsets.destroy',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsetsController@destroy',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsetsController@destroy',
        'namespace' => NULL,
        'prefix' => '/fields',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fields.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'fields',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fields.index',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsController@index',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fields.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'fields/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fields.create',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsController@create',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fields.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'fields',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fields.store',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsController@store',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fields.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'fields/{field}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fields.edit',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsController@edit',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fields.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'fields/{field}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fields.update',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsController@update',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'fields.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'fields/{field}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'fields.destroy',
        'uses' => 'App\\Http\\Controllers\\CustomFieldsController@destroy',
        'controller' => 'App\\Http\\Controllers\\CustomFieldsController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.checkout.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'components/{componentID}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentCheckoutController@create',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentCheckoutController@create',
        'namespace' => NULL,
        'prefix' => '/components',
        'where' => 
        array (
        ),
        'as' => 'components.checkout.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.checkout.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'components/{componentID}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentCheckoutController@store',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentCheckoutController@store',
        'namespace' => NULL,
        'prefix' => '/components',
        'where' => 
        array (
        ),
        'as' => 'components.checkout.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.checkin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'components/{componentID}/checkin/{backto?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentCheckinController@create',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentCheckinController@create',
        'namespace' => NULL,
        'prefix' => '/components',
        'where' => 
        array (
        ),
        'as' => 'components.checkin.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.checkin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'components/{componentID}/checkin/{backto?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentCheckinController@store',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentCheckinController@store',
        'namespace' => NULL,
        'prefix' => '/components',
        'where' => 
        array (
        ),
        'as' => 'components.checkin.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'components',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'components.index',
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentsController@index',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentsController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'components/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'components.create',
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentsController@create',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentsController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'components',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'components.store',
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentsController@store',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentsController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'components/{component}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'components.show',
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentsController@show',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentsController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'components/{component}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'components.edit',
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentsController@edit',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentsController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'components/{component}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'components.update',
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentsController@update',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentsController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'components.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'components/{component}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'components.destroy',
        'uses' => 'App\\Http\\Controllers\\Components\\ComponentsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Components\\ComponentsController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ldap/user' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/ldap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\LDAPImportController@create',
        'controller' => 'App\\Http\\Controllers\\Users\\LDAPImportController@create',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'ldap/user',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::djPLSWcWRo3QhYzF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users/ldap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\LDAPImportController@store',
        'controller' => 'App\\Http\\Controllers\\Users\\LDAPImportController@store',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'generated::djPLSWcWRo3QhYzF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@getExportUserCsv',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@getExportUserCsv',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users.export',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.clone.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/{user}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@getClone',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@getClone',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users.clone.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'users.clone.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users/{user}/clone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@postCreate',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@postCreate',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users.clone.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'users.restore.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users/{userId}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@getRestore',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@getRestore',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users.restore.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'unsuspend/user' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/{userId}/unsuspend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@getUnsuspend',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@getUnsuspend',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'unsuspend/user',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users/{userId}/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@sendPasswordReset',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@sendPasswordReset',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users.password',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/{userId}/print',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@printInventory',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@printInventory',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users/{userId}/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@emailAssetList',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@emailAssetList',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users/bulkedit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users/bulkedit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\BulkUsersController@edit',
        'controller' => 'App\\Http\\Controllers\\Users\\BulkUsersController@edit',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users/bulkedit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.merge.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users/merge',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\BulkUsersController@merge',
        'controller' => 'App\\Http\\Controllers\\Users\\BulkUsersController@merge',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users.merge.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users/bulksave' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users/bulksave',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\BulkUsersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Users\\BulkUsersController@destroy',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users/bulksave',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users/bulkeditsave' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users/bulkeditsave',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\BulkUsersController@update',
        'controller' => 'App\\Http\\Controllers\\Users\\BulkUsersController@update',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
        'as' => 'users/bulkeditsave',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'users.index',
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@index',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'users.create',
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@create',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'users.store',
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@store',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'users.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'users.show',
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@show',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'users.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/{user}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'users.edit',
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@edit',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'users.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'users.update',
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@update',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => true,
    ),
    'users.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'users.destroy',
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.licenses.store' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kits/{kit}/licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@storeLicense',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@storeLicense',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.licenses.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.licenses.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kits/{kit}/licenses/{license_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@updateLicense',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@updateLicense',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.licenses.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.licenses.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kits/{kit}/licenses/{license_id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@editLicense',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@editLicense',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.licenses.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:390:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:174:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.backups\'), \\route(\'kits.licenses.edit\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000f130000000000000000";}";s:4:"hash";s:44:"oI4EOghJzTEK+vsPrfy9GLCyQnr0DKR+xpJiXcK3RxM=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.licenses.detach' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'kits/{kit}/licenses/{license_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@detachLicense',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@detachLicense',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.licenses.detach',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.models.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kits/{kit}/models/{model_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@updateModel',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@updateModel',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.models.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.models.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kits/{kit}/models/{model_id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@editModel',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@editModel',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.models.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.models.detach' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'kits/{kit}/models/{model_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@detachModel',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@detachModel',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.models.detach',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.consumables.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kits/{kit}/consumables/{consumable_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@updateConsumable',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@updateConsumable',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.consumables.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.consumables.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kits/{kit}/consumables/{consumable_id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@editConsumable',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@editConsumable',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.consumables.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.consumables.detach' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'kits/{kit}/consumables/{consumable_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@detachConsumable',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@detachConsumable',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.consumables.detach',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.accessories.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kits/{kit}/accessories/{accessory_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@updateAccessory',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@updateAccessory',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.accessories.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.accessories.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kits/{kit}/accessories/{accessory_id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@editAccessory',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@editAccessory',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.accessories.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.accessories.detach' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'kits/{kit}/accessories/{accessory_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@detachAccessory',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@detachAccessory',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.accessories.detach',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.checkout.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kits/{kit}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\CheckoutKitController@showCheckout',
        'controller' => 'App\\Http\\Controllers\\Kits\\CheckoutKitController@showCheckout',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.checkout.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:415:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:199:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, \\App\\Models\\PredefinedKit $kit) =>
        $trail->parent(\'kits.show\', $kit)
            ->push(\\trans(\'general.checkout\'), \\route(\'kits.checkout.show\', $kit))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000f1e0000000000000000";}";s:4:"hash";s:44:"hHJV20grejUs/sxB6j+2fbRi/jxK+BUJaOT3MM+/G3o=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.checkout.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kits/{kit}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Kits\\CheckoutKitController@store',
        'controller' => 'App\\Http\\Controllers\\Kits\\CheckoutKitController@store',
        'namespace' => NULL,
        'prefix' => '/kits/{kit}',
        'where' => 
        array (
        ),
        'as' => 'kits.checkout.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'kits.index',
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@index',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kits/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'kits.create',
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@create',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'kits.store',
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@store',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kits/{kit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'kits.show',
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@show',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kits/{kit}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'kits.edit',
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@edit',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'kits/{kit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'kits.update',
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@update',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kits.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'kits/{kit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'kits.destroy',
        'uses' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Kits\\PredefinedKitsController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'companies.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'companies.index',
        'uses' => 'App\\Http\\Controllers\\CompaniesController@index',
        'controller' => 'App\\Http\\Controllers\\CompaniesController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'companies.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'companies/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'companies.create',
        'uses' => 'App\\Http\\Controllers\\CompaniesController@create',
        'controller' => 'App\\Http\\Controllers\\CompaniesController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'companies.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'companies.store',
        'uses' => 'App\\Http\\Controllers\\CompaniesController@store',
        'controller' => 'App\\Http\\Controllers\\CompaniesController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'companies.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'companies/{company}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'companies.show',
        'uses' => 'App\\Http\\Controllers\\CompaniesController@show',
        'controller' => 'App\\Http\\Controllers\\CompaniesController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'companies.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'companies/{company}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'companies.edit',
        'uses' => 'App\\Http\\Controllers\\CompaniesController@edit',
        'controller' => 'App\\Http\\Controllers\\CompaniesController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'companies.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'companies/{company}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'companies.update',
        'uses' => 'App\\Http\\Controllers\\CompaniesController@update',
        'controller' => 'App\\Http\\Controllers\\CompaniesController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'companies.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'companies/{company}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'companies.destroy',
        'uses' => 'App\\Http\\Controllers\\CompaniesController@destroy',
        'controller' => 'App\\Http\\Controllers\\CompaniesController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'categories.index',
        'uses' => 'App\\Http\\Controllers\\CategoriesController@index',
        'controller' => 'App\\Http\\Controllers\\CategoriesController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'categories/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'categories.create',
        'uses' => 'App\\Http\\Controllers\\CategoriesController@create',
        'controller' => 'App\\Http\\Controllers\\CategoriesController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'categories.store',
        'uses' => 'App\\Http\\Controllers\\CategoriesController@store',
        'controller' => 'App\\Http\\Controllers\\CategoriesController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'categories.show',
        'uses' => 'App\\Http\\Controllers\\CategoriesController@show',
        'controller' => 'App\\Http\\Controllers\\CategoriesController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'categories/{category}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'categories.edit',
        'uses' => 'App\\Http\\Controllers\\CategoriesController@edit',
        'controller' => 'App\\Http\\Controllers\\CategoriesController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'categories.update',
        'uses' => 'App\\Http\\Controllers\\CategoriesController@update',
        'controller' => 'App\\Http\\Controllers\\CategoriesController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'categories.destroy',
        'uses' => 'App\\Http\\Controllers\\CategoriesController@destroy',
        'controller' => 'App\\Http\\Controllers\\CategoriesController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.bulk.delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'categories/bulk/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\BulkCategoriesController@destroy',
        'controller' => 'App\\Http\\Controllers\\BulkCategoriesController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'categories.bulk.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'labels.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'labels/{labelName}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelsController@show',
        'controller' => 'App\\Http\\Controllers\\LabelsController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'labels.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'labelName' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lx1vWfVl9IKehEk8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'test-email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:143:"function () {
        $mailable = new \\App\\Mail\\CheckoutComponentMail(

        );
        return $mailable->render(); // dumps HTML
    }";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000f280000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lx1vWfVl9IKehEk8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'restore/manufacturer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'manufacturers/{manufacturers_id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ManufacturersController@restore',
        'controller' => 'App\\Http\\Controllers\\ManufacturersController@restore',
        'namespace' => NULL,
        'prefix' => '/manufacturers',
        'where' => 
        array (
        ),
        'as' => 'restore/manufacturer',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manufacturers.seed' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'manufacturers/seed',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ManufacturersController@seed',
        'controller' => 'App\\Http\\Controllers\\ManufacturersController@seed',
        'namespace' => NULL,
        'prefix' => '/manufacturers',
        'where' => 
        array (
        ),
        'as' => 'manufacturers.seed',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manufacturers.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manufacturers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'manufacturers.index',
        'uses' => 'App\\Http\\Controllers\\ManufacturersController@index',
        'controller' => 'App\\Http\\Controllers\\ManufacturersController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manufacturers.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manufacturers/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'manufacturers.create',
        'uses' => 'App\\Http\\Controllers\\ManufacturersController@create',
        'controller' => 'App\\Http\\Controllers\\ManufacturersController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manufacturers.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'manufacturers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'manufacturers.store',
        'uses' => 'App\\Http\\Controllers\\ManufacturersController@store',
        'controller' => 'App\\Http\\Controllers\\ManufacturersController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manufacturers.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manufacturers/{manufacturer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'manufacturers.show',
        'uses' => 'App\\Http\\Controllers\\ManufacturersController@show',
        'controller' => 'App\\Http\\Controllers\\ManufacturersController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manufacturers.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manufacturers/{manufacturer}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'manufacturers.edit',
        'uses' => 'App\\Http\\Controllers\\ManufacturersController@edit',
        'controller' => 'App\\Http\\Controllers\\ManufacturersController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manufacturers.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'manufacturers/{manufacturer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'manufacturers.update',
        'uses' => 'App\\Http\\Controllers\\ManufacturersController@update',
        'controller' => 'App\\Http\\Controllers\\ManufacturersController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manufacturers.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'manufacturers/{manufacturer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'manufacturers.destroy',
        'uses' => 'App\\Http\\Controllers\\ManufacturersController@destroy',
        'controller' => 'App\\Http\\Controllers\\ManufacturersController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manufacturers.bulk.delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'manufacturers/bulk/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\BulkManufacturersController@destroy',
        'controller' => 'App\\Http\\Controllers\\BulkManufacturersController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'manufacturers.bulk.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suppliers.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'suppliers.index',
        'uses' => 'App\\Http\\Controllers\\SuppliersController@index',
        'controller' => 'App\\Http\\Controllers\\SuppliersController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suppliers.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'suppliers/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'suppliers.create',
        'uses' => 'App\\Http\\Controllers\\SuppliersController@create',
        'controller' => 'App\\Http\\Controllers\\SuppliersController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suppliers.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'suppliers.store',
        'uses' => 'App\\Http\\Controllers\\SuppliersController@store',
        'controller' => 'App\\Http\\Controllers\\SuppliersController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suppliers.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'suppliers/{supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'suppliers.show',
        'uses' => 'App\\Http\\Controllers\\SuppliersController@show',
        'controller' => 'App\\Http\\Controllers\\SuppliersController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suppliers.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'suppliers/{supplier}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'suppliers.edit',
        'uses' => 'App\\Http\\Controllers\\SuppliersController@edit',
        'controller' => 'App\\Http\\Controllers\\SuppliersController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suppliers.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'suppliers/{supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'suppliers.update',
        'uses' => 'App\\Http\\Controllers\\SuppliersController@update',
        'controller' => 'App\\Http\\Controllers\\SuppliersController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suppliers.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'suppliers/{supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'suppliers.destroy',
        'uses' => 'App\\Http\\Controllers\\SuppliersController@destroy',
        'controller' => 'App\\Http\\Controllers\\SuppliersController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suppliers.bulk.delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'suppliers/bulk/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\BulkSuppliersController@destroy',
        'controller' => 'App\\Http\\Controllers\\BulkSuppliersController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suppliers.bulk.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'depreciations.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'depreciations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'depreciations.index',
        'uses' => 'App\\Http\\Controllers\\DepreciationsController@index',
        'controller' => 'App\\Http\\Controllers\\DepreciationsController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'depreciations.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'depreciations/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'depreciations.create',
        'uses' => 'App\\Http\\Controllers\\DepreciationsController@create',
        'controller' => 'App\\Http\\Controllers\\DepreciationsController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'depreciations.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'depreciations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'depreciations.store',
        'uses' => 'App\\Http\\Controllers\\DepreciationsController@store',
        'controller' => 'App\\Http\\Controllers\\DepreciationsController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'depreciations.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'depreciations/{depreciation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'depreciations.show',
        'uses' => 'App\\Http\\Controllers\\DepreciationsController@show',
        'controller' => 'App\\Http\\Controllers\\DepreciationsController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'depreciations.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'depreciations/{depreciation}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'depreciations.edit',
        'uses' => 'App\\Http\\Controllers\\DepreciationsController@edit',
        'controller' => 'App\\Http\\Controllers\\DepreciationsController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'depreciations.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'depreciations/{depreciation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'depreciations.update',
        'uses' => 'App\\Http\\Controllers\\DepreciationsController@update',
        'controller' => 'App\\Http\\Controllers\\DepreciationsController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'depreciations.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'depreciations/{depreciation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'depreciations.destroy',
        'uses' => 'App\\Http\\Controllers\\DepreciationsController@destroy',
        'controller' => 'App\\Http\\Controllers\\DepreciationsController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'statuslabels.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statuslabels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'statuslabels.index',
        'uses' => 'App\\Http\\Controllers\\StatuslabelsController@index',
        'controller' => 'App\\Http\\Controllers\\StatuslabelsController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'statuslabels.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statuslabels/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'statuslabels.create',
        'uses' => 'App\\Http\\Controllers\\StatuslabelsController@create',
        'controller' => 'App\\Http\\Controllers\\StatuslabelsController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'statuslabels.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'statuslabels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'statuslabels.store',
        'uses' => 'App\\Http\\Controllers\\StatuslabelsController@store',
        'controller' => 'App\\Http\\Controllers\\StatuslabelsController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'statuslabels.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statuslabels/{statuslabel}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'statuslabels.show',
        'uses' => 'App\\Http\\Controllers\\StatuslabelsController@show',
        'controller' => 'App\\Http\\Controllers\\StatuslabelsController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'statuslabels.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statuslabels/{statuslabel}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'statuslabels.edit',
        'uses' => 'App\\Http\\Controllers\\StatuslabelsController@edit',
        'controller' => 'App\\Http\\Controllers\\StatuslabelsController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'statuslabels.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'statuslabels/{statuslabel}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'statuslabels.update',
        'uses' => 'App\\Http\\Controllers\\StatuslabelsController@update',
        'controller' => 'App\\Http\\Controllers\\StatuslabelsController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'statuslabels.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'statuslabels/{statuslabel}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'statuslabels.destroy',
        'uses' => 'App\\Http\\Controllers\\StatuslabelsController@destroy',
        'controller' => 'App\\Http\\Controllers\\StatuslabelsController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'departments.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'departments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'departments.index',
        'uses' => 'App\\Http\\Controllers\\DepartmentsController@index',
        'controller' => 'App\\Http\\Controllers\\DepartmentsController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'departments.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'departments/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'departments.create',
        'uses' => 'App\\Http\\Controllers\\DepartmentsController@create',
        'controller' => 'App\\Http\\Controllers\\DepartmentsController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'departments.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'departments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'departments.store',
        'uses' => 'App\\Http\\Controllers\\DepartmentsController@store',
        'controller' => 'App\\Http\\Controllers\\DepartmentsController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'departments.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'departments/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'departments.show',
        'uses' => 'App\\Http\\Controllers\\DepartmentsController@show',
        'controller' => 'App\\Http\\Controllers\\DepartmentsController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'departments.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'departments/{department}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'departments.edit',
        'uses' => 'App\\Http\\Controllers\\DepartmentsController@edit',
        'controller' => 'App\\Http\\Controllers\\DepartmentsController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'departments.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'departments/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'departments.update',
        'uses' => 'App\\Http\\Controllers\\DepartmentsController@update',
        'controller' => 'App\\Http\\Controllers\\DepartmentsController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'departments.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'departments/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'as' => 'departments.destroy',
        'uses' => 'App\\Http\\Controllers\\DepartmentsController@destroy',
        'controller' => 'App\\Http\\Controllers\\DepartmentsController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'modal.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modals/{type}/{itemId?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ModalController@show',
        'controller' => 'App\\Http\\Controllers\\ModalController@show',
        'namespace' => NULL,
        'prefix' => '/modals',
        'where' => 
        array (
        ),
        'as' => 'modal.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'log.signature.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'display-sig/{filename}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ActionlogController@displaySig',
        'controller' => 'App\\Http\\Controllers\\ActionlogController@displaySig',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'log.signature.view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'log.storedeula.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'stored-eula-file/{filename}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ActionlogController@getStoredEula',
        'controller' => 'App\\Http\\Controllers\\ActionlogController@getStoredEula',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'log.storedeula.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.general.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getSettings',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getSettings',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.general.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:400:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:184:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.general_title\'), \\route(\'settings.general.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000f630000000000000000";}";s:4:"hash";s:44:"ikRxhknjwcd0g3yjfddMcpLZ90gWtKz1imDsxPxOw0o=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.general.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postSettings',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postSettings',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.general.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.branding.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/branding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getBranding',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getBranding',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.branding.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:402:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:186:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.branding_title\'), \\route(\'settings.branding.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000f650000000000000000";}";s:4:"hash";s:44:"ZugpZD+ALLBFcicQz/+DRve4IfruuLY/3IJE0dEPc2Y=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.branding.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/branding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postBranding',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postBranding',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.branding.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.security.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/security',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getSecurity',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getSecurity',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.security.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:402:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:186:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.security_title\'), \\route(\'settings.security.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000f670000000000000000";}";s:4:"hash";s:44:"5lFnptRJMj8YImf7fUDkIQ7ZVLwMdC2wMbCd1hLg7Ok=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.security.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/security',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postSecurity',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postSecurity',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.security.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.localization.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/localization',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getLocalization',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getLocalization',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.localization.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:410:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:194:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.localization_title\'), \\route(\'settings.localization.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000f680000000000000000";}";s:4:"hash";s:44:"2jvgbfRla9yIKhog+5sfVqPHBPwJJNJoe0a0/hDesBg=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.localization.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/localization',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postLocalization',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postLocalization',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.localization.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.alerts.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/notifications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getAlerts',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getAlerts',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.alerts.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:397:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:181:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.alert_title\'), \\route(\'settings.alerts.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000050f0000000000000000";}";s:4:"hash";s:44:"Mwdw74S4Qv+zfq/21ZP4XF4R+O00V0Fj4T/27hPpmA0=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.alerts.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/notifications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postAlerts',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postAlerts',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.alerts.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.slack.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/slack',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getSlack',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getSlack',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.slack.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:398:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:182:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.webhook_title\'), \\route(\'settings.slack.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000005190000000000000000";}";s:4:"hash";s:44:"k01VUVF4VxRmntIjt2gdtFr1KzhiBFpSy3oNr8/qMcM=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.slack.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/slack',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postSlack',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postSlack',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.slack.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.asset_tags.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/asset_tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getAssetTags',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getAssetTags',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.asset_tags.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:405:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:189:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.asset_tag_title\'), \\route(\'settings.asset_tags.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000051a0000000000000000";}";s:4:"hash";s:44:"++P9bz9k0sRShJLC284SU56rszq+L75bjJpahZTlyVs=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.asset_tags.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/asset_tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postAssetTags',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postAssetTags',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.asset_tags.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.labels.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/labels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getLabels',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getLabels',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.labels.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:398:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:182:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.labels_title\'), \\route(\'settings.labels.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000051b0000000000000000";}";s:4:"hash";s:44:"xRkpU9+p8Jvp5DFGbwnxp1m8h3oRzu3ZrpuCLIqOPlw=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.labels.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/labels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postLabels',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postLabels',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.labels.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.ldap.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ldap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getLdapSettings',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getLdapSettings',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.ldap.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:391:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:175:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.ldap_ad\'), \\route(\'settings.ldap.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000005110000000000000000";}";s:4:"hash";s:44:"H7+13JYHVlFdf2WUkuRkATGKJ09lEZiSC25P4IoD2HI=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.ldap.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/ldap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postLdapSettings',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postLdapSettings',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.ldap.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.phpinfo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/phpinfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getPhpInfo',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getPhpInfo',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.phpinfo.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:395:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:179:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.php_info\'), \\route(\'settings.phpinfo.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000050c0000000000000000";}";s:4:"hash";s:44:"jbBh+3bYsri8Sp6y3RGLdIhCywZyR1iQK9neNgGFnmU=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.oauth.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/oauth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@api',
        'controller' => 'App\\Http\\Controllers\\SettingsController@api',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.oauth.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:390:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:174:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.oauth\'), \\route(\'settings.oauth.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000050c0000000000000000";}";s:4:"hash";s:44:"VbLw60m2LGJ5TZSS2skZ0kXlnSVnYApjC8S3pwSad3c=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.google.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/google',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getGoogleLoginSettings',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getGoogleLoginSettings',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.google.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:398:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:182:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.google_login\'), \\route(\'settings.google.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000050c0000000000000000";}";s:4:"hash";s:44:"FFjcR08nZ98y2EBMkWB7nu2mGtBO5WzTsoNgo/++AJY=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.google.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/google',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postGoogleLoginSettings',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postGoogleLoginSettings',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.google.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.purge.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/purge',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getPurge',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getPurge',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.purge.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:390:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:174:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.purge\'), \\route(\'settings.purge.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000053a0000000000000000";}";s:4:"hash";s:44:"AYws5zekYoq8ORo8h96cUdMFUB9+Pm6BRAhlnl+ZS88=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.purge.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/purge',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postPurge',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postPurge',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.purge.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.logins.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/login-attempts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getLoginAttempts',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getLoginAttempts',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.logins.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:391:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:175:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.login\'), \\route(\'settings.logins.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000052f0000000000000000";}";s:4:"hash";s:44:"ZkE4nKohJ3on72jPOdYOcjFgojNV4HzWYhP1pdASTDE=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.saml.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/saml',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getSamlSettings',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getSamlSettings',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.saml.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:394:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:178:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'settings.index\')
            ->push(\\trans(\'admin/settings/general.saml_title\'), \\route(\'settings.saml.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000052f0000000000000000";}";s:4:"hash";s:44:"L2t1B7+zJ/syCaOxlrQhBCuYg0fsqTsNxM3KOVntahw=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.saml.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/saml',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postSamlSettings',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postSamlSettings',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.saml.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.backups.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/backups/download/{filename}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@downloadFile',
        'controller' => 'App\\Http\\Controllers\\SettingsController@downloadFile',
        'namespace' => NULL,
        'prefix' => 'admin/backups',
        'where' => 
        array (
        ),
        'as' => 'settings.backups.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.backups.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/backups/delete/{filename}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@deleteFile',
        'controller' => 'App\\Http\\Controllers\\SettingsController@deleteFile',
        'namespace' => NULL,
        'prefix' => 'admin/backups',
        'where' => 
        array (
        ),
        'as' => 'settings.backups.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.backups.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/backups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postBackups',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postBackups',
        'namespace' => NULL,
        'prefix' => 'admin/backups',
        'where' => 
        array (
        ),
        'as' => 'settings.backups.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.backups.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/backups/restore/{filename}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postRestore',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postRestore',
        'namespace' => NULL,
        'prefix' => 'admin/backups',
        'where' => 
        array (
        ),
        'as' => 'settings.backups.restore',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.backups.upload' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/backups/upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postUploadBackup',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postUploadBackup',
        'namespace' => NULL,
        'prefix' => 'admin/backups',
        'where' => 
        array (
        ),
        'as' => 'settings.backups.upload',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tEvRz1yMYhg0wyu6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/backups/restore/{filename?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'auth',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:89:"function () {
            return \\redirect(\\route(\'settings.backups.index\'));
        }";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000005750000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'admin/backups',
        'where' => 
        array (
        ),
        'as' => 'generated::tEvRz1yMYhg0wyu6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.backups.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/backups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'auth',
          4 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getBackups',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getBackups',
        'namespace' => NULL,
        'prefix' => 'admin/backups',
        'where' => 
        array (
        ),
        'as' => 'settings.backups.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:402:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:186:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
            $trail->parent(\'settings.index\')
                ->push(\\trans(\'admin/settings/general.backups\'), \\route(\'settings.backups.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000056a0000000000000000";}";s:4:"hash";s:44:"lrUgsJ0Xl4pFSH3gvKbedy4lL1ywkows9i0Xa77M6Zg=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'groups.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'as' => 'groups.index',
        'uses' => 'App\\Http\\Controllers\\GroupsController@index',
        'controller' => 'App\\Http\\Controllers\\GroupsController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'groups.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/groups/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'as' => 'groups.create',
        'uses' => 'App\\Http\\Controllers\\GroupsController@create',
        'controller' => 'App\\Http\\Controllers\\GroupsController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'groups.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'as' => 'groups.store',
        'uses' => 'App\\Http\\Controllers\\GroupsController@store',
        'controller' => 'App\\Http\\Controllers\\GroupsController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'groups.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/groups/{group}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'as' => 'groups.show',
        'uses' => 'App\\Http\\Controllers\\GroupsController@show',
        'controller' => 'App\\Http\\Controllers\\GroupsController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'groups.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/groups/{group}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'as' => 'groups.edit',
        'uses' => 'App\\Http\\Controllers\\GroupsController@edit',
        'controller' => 'App\\Http\\Controllers\\GroupsController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'groups.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/groups/{group}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'as' => 'groups.update',
        'uses' => 'App\\Http\\Controllers\\GroupsController@update',
        'controller' => 'App\\Http\\Controllers\\GroupsController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'groups.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/groups/{group}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
        ),
        'as' => 'groups.destroy',
        'uses' => 'App\\Http\\Controllers\\GroupsController@destroy',
        'controller' => 'App\\Http\\Controllers\\GroupsController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:superuser',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@index',
        'controller' => 'App\\Http\\Controllers\\SettingsController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'settings.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:359:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:143:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.admin\'), \\route(\'settings.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000052f0000000000000000";}";s:4:"hash";s:44:"0F0x4mWcmbRqTW/f0Go0j6ovlhl4MxfYbNIOP23Lhs8=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'imports.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Livewire\\Importer@__invoke',
        'controller' => 'App\\Livewire\\Importer',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'imports.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:351:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:135:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
    $trail->parent(\'home\')
        ->push(\\trans(\'general.import\'), \\route(\'imports.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000056a0000000000000000";}";s:4:"hash";s:44:"G/LPnGJG4zPdblooA3QJjQ15Aq4uKPCQGMKReI/k868=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@getIndex',
        'controller' => 'App\\Http\\Controllers\\ProfileController@getIndex',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:366:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:150:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
                $trail->parent(\'home\')
            ->push(\\trans(\'general.editprofile\'), \\route(\'profile\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000005820000000000000000";}";s:4:"hash";s:44:"+kUFhBdO6FqVOb0/fXUJcLBtqiQ96WTZWCyRW4kNq1M=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@postIndex',
        'controller' => 'App\\Http\\Controllers\\ProfileController@postIndex',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'profile.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.menuprefs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@getMenuState',
        'controller' => 'App\\Http\\Controllers\\ProfileController@getMenuState',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account.menuprefs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.password.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@password',
        'controller' => 'App\\Http\\Controllers\\ProfileController@password',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account.password.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:376:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:160:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.changepassword\'), \\route(\'account.password.index\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000005770000000000000000";}";s:4:"hash";s:44:"k0+tvXTMB3z2S7VXtL5P5Z6ChG9UMntQ7scACZ/GH88=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@passwordSave',
        'controller' => 'App\\Http\\Controllers\\ProfileController@passwordSave',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account.password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.api' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/api',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@api',
        'controller' => 'App\\Http\\Controllers\\ProfileController@api',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'user.api',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:363:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:147:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.manage_api_keys\'), \\route(\'user.api\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000057d0000000000000000";}";s:4:"hash";s:44:"eUsCc17YHH5cTwSALkimQaK18Mj5b7l02fWNEFR4DNI=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'view-assets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/view-assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ViewAssetsController@getIndex',
        'controller' => 'App\\Http\\Controllers\\ViewAssetsController@getIndex',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'view-assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:361:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:145:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.viewassets\'), \\route(\'view-assets\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000057d0000000000000000";}";s:4:"hash";s:44:"b/2n329O/RIaoChUkcuz/AXxbJqLIzXIItuJcShoLs8=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.requested' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/requested',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ViewAssetsController@getRequestedAssets',
        'controller' => 'App\\Http\\Controllers\\ViewAssetsController@getRequestedAssets',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account.requested',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:378:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:162:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.requested_assets_menu\'), \\route(\'account.requested\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000057d0000000000000000";}";s:4:"hash";s:44:"nJpjkyZaQoFAcoghnyh8OQvOobslFiFjc4Roj/2jlGY=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'requestable-assets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/requestable-assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ViewAssetsController@getRequestableIndex',
        'controller' => 'App\\Http\\Controllers\\ViewAssetsController@getRequestableIndex',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'requestable-assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:375:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:159:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.requestable_items\'), \\route(\'requestable-assets\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000057d0000000000000000";}";s:4:"hash";s:44:"c9RllUWhAF+S63egfN6KfRojzOHAsVNESCTA8nV22+k=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.request-asset' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/request-asset/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ViewAssetsController@store',
        'controller' => 'App\\Http\\Controllers\\ViewAssetsController@store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account.request-asset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.request-asset.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/request-asset/{asset}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ViewAssetsController@destroy',
        'controller' => 'App\\Http\\Controllers\\ViewAssetsController@destroy',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account.request-asset.cancel',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account/request-item' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/request/{itemType}/{itemId}/{cancel_by_admin?}/{requestingUser?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ViewAssetsController@getRequestItem',
        'controller' => 'App\\Http\\Controllers\\ViewAssetsController@getRequestItem',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account/request-item',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.signature.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/display-sig/{filename}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@displaySig',
        'controller' => 'App\\Http\\Controllers\\ProfileController@displaySig',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'profile.signature.view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.storedeula.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/stored-eula-file/{filename}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@getStoredEula',
        'controller' => 'App\\Http\\Controllers\\ProfileController@getStoredEula',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'profile.storedeula.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ViewAssetsController@getIndex',
        'controller' => 'App\\Http\\Controllers\\ViewAssetsController@getIndex',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.accept' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/accept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Account\\AcceptanceController@index',
        'controller' => 'App\\Http\\Controllers\\Account\\AcceptanceController@index',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account.accept',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:372:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:156:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.accept_assets_menu\'), \\route(\'account.accept\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008540000000000000000";}";s:4:"hash";s:44:"jhb88+NVKFbkWPhQ0UjziXF7PVw2LS8eDOja/KOEvKc=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.accept.item' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/accept/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\Account\\AcceptanceController@create',
        'controller' => 'App\\Http\\Controllers\\Account\\AcceptanceController@create',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account.accept.item',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:390:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:174:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, $id) =>
        $trail->parent(\'account.accept\')
            ->push(\\trans(\'general.accept_item\'), \\route(\'account.accept.item\', $id))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008540000000000000000";}";s:4:"hash";s:44:"tFXHfPPoPb1YAFVzEYmGchXM7qnkL1dhMLZR/Is5jT0=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.store-acceptance' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/accept/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Account\\AcceptanceController@store',
        'controller' => 'App\\Http\\Controllers\\Account\\AcceptanceController@store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'account.store-acceptance',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/print',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@printInventory',
        'controller' => 'App\\Http\\Controllers\\ProfileController@printInventory',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'profile.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.email_assets' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@emailAssetList',
        'controller' => 'App\\Http\\Controllers\\ProfileController@emailAssetList',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
        'as' => 'profile.email_assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'notes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'notes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\NotesController@store',
        'controller' => 'App\\Http\\Controllers\\NotesController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'notes.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.audit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/audit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@audit',
        'controller' => 'App\\Http\\Controllers\\ReportsController@audit',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports.audit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:365:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:149:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.audit_report\'), \\route(\'reports.audit\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008530000000000000000";}";s:4:"hash";s:44:"9lvwDZ90lN/OBAW8Ozjb4LT3Cx+V2JplOdeQHT940rc=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/depreciation' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/depreciation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@getDeprecationReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@getDeprecationReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/depreciation',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:379:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:163:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.depreciation_report\'), \\route(\'reports/depreciation\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008530000000000000000";}";s:4:"hash";s:44:"1+i7OOzBbP8uIOcPcvCnC6NdDGJL8IwbzGsn2eu2yuw=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/export/depreciation' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/export/depreciation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@exportDeprecationReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@exportDeprecationReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/export/depreciation',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:372:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:156:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.depreciation_report\'), \\route(\'reports.audit\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008530000000000000000";}";s:4:"hash";s:44:"CwPDeIfPLWNgSr9hl9tRrGeOGAvRvu7OGr9kRHfswhg=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ui.reports.maintenances' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/maintenances',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@getMaintenancesReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@getMaintenancesReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'ui.reports.maintenances',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:387:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:171:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.asset_maintenance_report\'), \\route(\'ui.reports.maintenances\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008530000000000000000";}";s:4:"hash";s:44:"mfLIlGd51+dYkdWDTD1Yevdx0PLIMwvIrYDb0gGzWww=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/export/maintenances' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/export/maintenances',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@exportMaintenancesReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@exportMaintenancesReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/export/maintenances',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:391:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:175:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.asset_maintenance_report\'), \\route(\'reports/export/maintenances\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008530000000000000000";}";s:4:"hash";s:44:"JF++x+YyPjsEBSuEhSzXWpKbSX3w4wG0y+Q200t3ntM=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/licenses' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@getLicenseReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@getLicenseReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/licenses',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:370:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:154:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.license_report\'), \\route(\'reports/licenses\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008530000000000000000";}";s:4:"hash";s:44:"URH9LRKzwiAKcyOWfRU8fRVo/3TPNRdNr9Ga0BOQBdw=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/export/licenses' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/export/licenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@exportLicenseReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@exportLicenseReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/export/licenses',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/accessories' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@getAccessoryReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@getAccessoryReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/accessories',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/export/accessories' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/export/accessories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@exportAccessoryReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@exportAccessoryReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/export/accessories',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/custom' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/custom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@getCustomReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@getCustomReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/custom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:367:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:151:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.custom_report\'), \\route(\'reports/custom\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008570000000000000000";}";s:4:"hash";s:44:"y0m7GXYvmP2eQWP+HsBLI+4kGqidAEhBV80Igdd6meA=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.post-custom' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reports/custom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@postCustom',
        'controller' => 'App\\Http\\Controllers\\ReportsController@postCustom',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports.post-custom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'report-templates.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reports/templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportTemplatesController@store',
        'controller' => 'App\\Http\\Controllers\\ReportTemplatesController@store',
        'namespace' => NULL,
        'prefix' => 'reports/templates',
        'where' => 
        array (
        ),
        'as' => 'report-templates.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'report-templates.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/templates/{reportTemplate}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportTemplatesController@show',
        'controller' => 'App\\Http\\Controllers\\ReportTemplatesController@show',
        'namespace' => NULL,
        'prefix' => 'reports/templates',
        'where' => 
        array (
        ),
        'as' => 'report-templates.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:475:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:259:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, \\App\\Models\\ReportTemplate $reportTemplate) =>
                $trail->parent(\'reports/custom\')
                    ->push($reportTemplate->name, null)
                    ->push(\\trans(\'general.customize_report\'), \'\')";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008b80000000000000000";}";s:4:"hash";s:44:"BzZ3vxx25iGigpoZqbbGRtjDpiCPw8g87fCi1GABkN0=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'report-templates.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/templates/{reportTemplate}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportTemplatesController@edit',
        'controller' => 'App\\Http\\Controllers\\ReportTemplatesController@edit',
        'namespace' => NULL,
        'prefix' => 'reports/templates',
        'where' => 
        array (
        ),
        'as' => 'report-templates.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:519:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:303:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, \\App\\Models\\ReportTemplate $reportTemplate) =>
                $trail->parent(\'reports/custom\')
                    ->push($reportTemplate->name, \\route(\'report-templates.show\', $reportTemplate))
                    ->push(\\trans(\'general.customize_report\'), \'\')";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008b80000000000000000";}";s:4:"hash";s:44:"v4lQogBqeD2ZMa78Aw99/fAqJc+73tpGWf+Y4PkWxLs=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'report-templates.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reports/templates/{reportTemplate}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportTemplatesController@update',
        'controller' => 'App\\Http\\Controllers\\ReportTemplatesController@update',
        'namespace' => NULL,
        'prefix' => 'reports/templates',
        'where' => 
        array (
        ),
        'as' => 'report-templates.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'report-templates.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'reports/templates/{reportTemplate}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportTemplatesController@destroy',
        'controller' => 'App\\Http\\Controllers\\ReportTemplatesController@destroy',
        'namespace' => NULL,
        'prefix' => 'reports/templates',
        'where' => 
        array (
        ),
        'as' => 'report-templates.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.activity' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/activity',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@getActivityReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@getActivityReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports.activity',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:371:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:155:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.activity_report\'), \\route(\'reports.activity\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000085a0000000000000000";}";s:4:"hash";s:44:"vasTohvxdoyOoviMM1ouhwv3lZ0OD1ImxUKvinDomp4=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.activity.post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reports/activity',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@postActivityReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@postActivityReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports.activity.post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/unaccepted_assets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/unaccepted_assets/{deleted?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@getAssetAcceptanceReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@getAssetAcceptanceReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/unaccepted_assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:388:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:172:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
        $trail->parent(\'home\')
            ->push(\\trans(\'general.unaccepted_asset_report\'), \\route(\'reports/unaccepted_assets\'))";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008b40000000000000000";}";s:4:"hash";s:44:"U+t6G98Jf2LPQen0h+0inQLAlKQ5y2hUPmJd9cWjLdo=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/unaccepted_assets_sent_reminder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reports/unaccepted_assets/sent_reminder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@sentAssetAcceptanceReminder',
        'controller' => 'App\\Http\\Controllers\\ReportsController@sentAssetAcceptanceReminder',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/unaccepted_assets_sent_reminder',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/unaccepted_assets_delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'reports/unaccepted_assets/{acceptanceId}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@deleteAssetAcceptance',
        'controller' => 'App\\Http\\Controllers\\ReportsController@deleteAssetAcceptance',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/unaccepted_assets_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports/export/unaccepted_assets' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reports/unaccepted_assets/{deleted?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportsController@postAssetAcceptanceReport',
        'controller' => 'App\\Http\\Controllers\\ReportsController@postAssetAcceptanceReport',
        'namespace' => NULL,
        'prefix' => '/reports',
        'where' => 
        array (
        ),
        'as' => 'reports/export/unaccepted_assets',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JUpLdOF4RL8RAsaE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/signin',
      'action' => 
      array (
        'middleware' => 'web',
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@legacyAuthRedirect',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@legacyAuthRedirect',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JUpLdOF4RL8RAsaE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'setup.user' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'setup/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getSetupUser',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getSetupUser',
        'namespace' => NULL,
        'prefix' => '/setup',
        'where' => 
        array (
        ),
        'as' => 'setup.user',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'setup.user.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'setup/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@postSaveFirstAdmin',
        'controller' => 'App\\Http\\Controllers\\SettingsController@postSaveFirstAdmin',
        'namespace' => NULL,
        'prefix' => '/setup',
        'where' => 
        array (
        ),
        'as' => 'setup.user.save',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'setup.migrate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'setup/migrate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getSetupMigrate',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getSetupMigrate',
        'namespace' => NULL,
        'prefix' => '/setup',
        'where' => 
        array (
        ),
        'as' => 'setup.migrate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'setup.done' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'setup/done',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getSetupDone',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getSetupDone',
        'namespace' => NULL,
        'prefix' => '/setup',
        'where' => 
        array (
        ),
        'as' => 'setup.done',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'setup.mailtest' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'setup/mailtest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@ajaxTestEmail',
        'controller' => 'App\\Http\\Controllers\\SettingsController@ajaxTestEmail',
        'namespace' => NULL,
        'prefix' => '/setup',
        'where' => 
        array (
        ),
        'as' => 'setup.mailtest',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'setup' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'setup',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\SettingsController@getSetupIndex',
        'controller' => 'App\\Http\\Controllers\\SettingsController@getSetupIndex',
        'namespace' => NULL,
        'prefix' => '/setup',
        'where' => 
        array (
        ),
        'as' => 'setup',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jPGSTHkTpOwCxpIA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jPGSTHkTpOwCxpIA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor-enroll' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'two-factor-enroll',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@getTwoFactorEnroll',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@getTwoFactorEnroll',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor-enroll',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'two-factor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@getTwoFactorAuth',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@getTwoFactorAuth',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PN2nEoTNcNMAZZPu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'two-factor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@postTwoFactorAuth',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@postTwoFactorAuth',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PN2nEoTNcNMAZZPu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
          2 => 'throttle:forgotten_password',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
          2 => 'throttle:forgotten_password',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
          2 => 'throttle:forgotten_password',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'google.redirect' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'google',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\GoogleAuthController@redirectToGoogle',
        'controller' => 'App\\Http\\Controllers\\GoogleAuthController@redirectToGoogle',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'google.redirect',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'google.callback' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'google/callback',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\GoogleAuthController@handleGoogleCallback',
        'controller' => 'App\\Http\\Controllers\\GoogleAuthController@handleGoogleCallback',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'google.callback',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout.get' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout.get',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout.post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout.post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ui.files.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{object_type}/{id}/files/{file_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\UploadedFilesController@show',
        'controller' => 'App\\Http\\Controllers\\UploadedFilesController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ui.files.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'object_type' => 'assets|audits|maintenances|hardware|models|users|locations|accessories|consumables|licenses|components',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ui.files.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{object_type}/{id}/files',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\UploadedFilesController@store',
        'controller' => 'App\\Http\\Controllers\\UploadedFilesController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ui.files.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'object_type' => 'assets|audits|maintenances|hardware|models|users|locations|accessories|consumables|licenses|components',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ui.files.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '{object_type}/{id}/files/{file_id}/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\UploadedFilesController@destroy',
        'controller' => 'App\\Http\\Controllers\\UploadedFilesController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ui.files.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'object_type' => 'assets|maintenances|hardware|models|users|locations|accessories|consumables|licenses|components',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'health' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'health',
      'action' => 
      array (
        'middleware' => 'web',
        'excluded_middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\App\\Http\\Controllers\\HealthController@get',
        'controller' => '\\App\\Http\\Controllers\\HealthController@get',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'health',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'breadcrumbs',
        ),
        'uses' => '\\App\\Http\\Controllers\\DashboardController@index',
        'controller' => '\\App\\Http\\Controllers\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:303:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:88:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) =>
    $trail->push(\'Home\', \\route(\'home\'))
    ";s:5:"scope";s:34:"App\\Providers\\RouteServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000008b30000000000000000";}";s:4:"hash";s:44:"Kv7Ve5rlxAT6ImPMfeIE9xX9oRume+ubRukQcwoavXo=";}}',
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scim.serviceproviderconfig' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v2/ServiceProviderConfig',
      'action' => 
      array (
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ServiceProviderController@index',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ServiceProviderController@index',
        'as' => 'scim.serviceproviderconfig',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OFM2tq9nljKUwhJT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v2/Schemas',
      'action' => 
      array (
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\SchemaController@index',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\SchemaController@index',
        'as' => 'generated::OFM2tq9nljKUwhJT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scim.schemas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v2/Schemas/{id}',
      'action' => 
      array (
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\SchemaController@show',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\SchemaController@show',
        'as' => 'scim.schemas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::S1a7HI3pEPfYRPXq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v2/ResourceTypes',
      'action' => 
      array (
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceTypesController@index',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceTypesController@index',
        'as' => 'generated::S1a7HI3pEPfYRPXq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scim.resourcetype' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v2/ResourceTypes/{id}',
      'action' => 
      array (
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceTypesController@show',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceTypesController@show',
        'as' => 'scim.resourcetype',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pag4vxGkdscBEYTZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'scim/v2/.search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
          2 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          3 => 'ArieTimmerman\\Laravel\\SCIMServer\\Middleware\\SCIMHeaders',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@notImplemented',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@notImplemented',
        'namespace' => NULL,
        'prefix' => 'scim/v2',
        'where' => 
        array (
        ),
        'as' => 'generated::pag4vxGkdscBEYTZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scim.resource' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v2/{resourceType}/{resourceObject}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
          2 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          3 => 'ArieTimmerman\\Laravel\\SCIMServer\\Middleware\\SCIMHeaders',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@show',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@show',
        'namespace' => NULL,
        'prefix' => 'scim/v2',
        'where' => 
        array (
        ),
        'as' => 'scim.resource',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scim.resources' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v2/{resourceType}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
          2 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          3 => 'ArieTimmerman\\Laravel\\SCIMServer\\Middleware\\SCIMHeaders',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@index',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@index',
        'namespace' => NULL,
        'prefix' => 'scim/v2',
        'where' => 
        array (
        ),
        'as' => 'scim.resources',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Qr1FDyUo4xj69pSf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'scim/v2/{resourceType}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
          2 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          3 => 'ArieTimmerman\\Laravel\\SCIMServer\\Middleware\\SCIMHeaders',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@create',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@create',
        'namespace' => NULL,
        'prefix' => 'scim/v2',
        'where' => 
        array (
        ),
        'as' => 'generated::Qr1FDyUo4xj69pSf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FQFnBZdZchNXp5ku' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'scim/v2/{resourceType}/{resourceObject}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
          2 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          3 => 'ArieTimmerman\\Laravel\\SCIMServer\\Middleware\\SCIMHeaders',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@replace',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@replace',
        'namespace' => NULL,
        'prefix' => 'scim/v2',
        'where' => 
        array (
        ),
        'as' => 'generated::FQFnBZdZchNXp5ku',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LHakJwSR4J040Kmp' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'scim/v2/{resourceType}/{resourceObject}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
          2 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          3 => 'ArieTimmerman\\Laravel\\SCIMServer\\Middleware\\SCIMHeaders',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@update',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@update',
        'namespace' => NULL,
        'prefix' => 'scim/v2',
        'where' => 
        array (
        ),
        'as' => 'generated::LHakJwSR4J040Kmp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9LgAR0wpxKbgeEcR' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'scim/v2/{resourceType}/{resourceObject}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
          2 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          3 => 'ArieTimmerman\\Laravel\\SCIMServer\\Middleware\\SCIMHeaders',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@delete',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@delete',
        'namespace' => NULL,
        'prefix' => 'scim/v2',
        'where' => 
        array (
        ),
        'as' => 'generated::9LgAR0wpxKbgeEcR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ib1G0nuzeiwnHBv8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v2/{fallbackPlaceholder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
          2 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          3 => 'ArieTimmerman\\Laravel\\SCIMServer\\Middleware\\SCIMHeaders',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@notImplemented',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@notImplemented',
        'namespace' => NULL,
        'prefix' => 'scim/v2',
        'where' => 
        array (
        ),
        'as' => 'generated::ib1G0nuzeiwnHBv8',
      ),
      'fallback' => true,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'fallbackPlaceholder' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5h82kf4qL8SvrHas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v1',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@wrongVersion',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@wrongVersion',
        'namespace' => NULL,
        'prefix' => '/scim',
        'where' => 
        array (
        ),
        'as' => 'generated::5h82kf4qL8SvrHas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cLhDy5IwDVJch5ot' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v1/{fallbackPlaceholder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@wrongVersion',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\ResourceController@wrongVersion',
        'namespace' => NULL,
        'prefix' => 'scim/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::cLhDy5IwDVJch5ot',
      ),
      'fallback' => true,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
        'fallbackPlaceholder' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scim.me.get' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'scim/v2/Me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\MeController@getMe',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\MeController@getMe',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'scim.me.get',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scim.me.put' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'scim/v2/Me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'auth:api',
          1 => 'authorize:superadmin',
        ),
        'uses' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\MeController@replaceMe',
        'controller' => '\\ArieTimmerman\\Laravel\\SCIMServer\\Http\\Controllers\\MeController@replaceMe',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'scim.me.put',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BDTliEbkNDMxIk8e' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@returnJavaScriptAsFile',
        'controller' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@returnJavaScriptAsFile',
        'as' => 'generated::BDTliEbkNDMxIk8e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'saml.metadata' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'saml/metadata',
      'action' => 
      array (
        'as' => 'saml.metadata',
        'uses' => 'App\\Http\\Controllers\\Auth\\SamlController@metadata',
        'controller' => 'App\\Http\\Controllers\\Auth\\SamlController@metadata',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/saml',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'saml.acs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'saml/acs',
      'action' => 
      array (
        'as' => 'saml.acs',
        'uses' => 'App\\Http\\Controllers\\Auth\\SamlController@acs',
        'controller' => 'App\\Http\\Controllers\\Auth\\SamlController@acs',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/saml',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'saml.sls' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'saml/sls',
      'action' => 
      array (
        'as' => 'saml.sls',
        'uses' => 'App\\Http\\Controllers\\Auth\\SamlController@sls',
        'controller' => 'App\\Http\\Controllers\\Auth\\SamlController@sls',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/saml',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'saml.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login/saml',
      'action' => 
      array (
        'as' => 'saml.login',
        'uses' => 'App\\Http\\Controllers\\Auth\\SamlController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\SamlController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'resourceType' => '^((?!Me).)*$',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
